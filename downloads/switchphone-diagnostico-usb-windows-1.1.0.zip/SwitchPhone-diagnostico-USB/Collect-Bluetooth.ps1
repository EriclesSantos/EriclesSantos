# Windows PowerShell 5.1+. Only numeric bond callback fields leave memory.
# ADB is downloaded from Google, checked, and kept beside this helper.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Convert-BondLine {
    param([string]$Line, [int]$ElapsedSeconds)
    $pattern = '^bondStateChangeCallback:\s+Status:\s+(?<status>\d{1,3})\s+Address:\s+[^\r\n]{1,128}?\s+newState:\s+(?<state>[0-2])\s+hciReason:\s+(?<reason>-1|\d{1,3})\s*$'
    if ($Line -cnotmatch $pattern) { return }
    $statusCode = [int]$Matches.status
    $reasonCode = [int]$Matches.reason
    if ($statusCode -gt 255 -or $reasonCode -gt 255) { return }
    [pscustomobject][ordered]@{
        elapsed_seconds = $ElapsedSeconds
        status = $statusCode
        native_bond_state = [int]$Matches.state
        hci_reason = $reasonCode
    }
}

function Start-AdbProcess {
    param([string]$AdbPath, [string]$Arguments)
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $AdbPath
    $info.Arguments = $Arguments
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    try { [void]$process.Start() }
    catch { $process.Dispose(); throw 'E_ADB_START' }
    return $process
}

function Invoke-AdbShort {
    param([string]$AdbPath, [string]$Arguments)
    $process = Start-AdbProcess $AdbPath $Arguments
    try {
        $outputTask = $process.StandardOutput.ReadToEndAsync()
        $errorTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) { $process.Kill(); throw 'E_ADB_TIMEOUT' }
        $outputText = $outputTask.GetAwaiter().GetResult()
        [void]$errorTask.GetAwaiter().GetResult()
        [pscustomobject]@{ Code = $process.ExitCode; Text = $outputText.Trim() }
    } finally { $process.Dispose() }
}

function Get-VerifiedAdb {
    param([string]$Directory)
    $toolRoot = Join-Path $Directory '.switchphone-tools'
    $adb = Join-Path $toolRoot 'platform-tools/adb.exe'
    if (-not (Test-Path -LiteralPath $adb -PathType Leaf)) {
        Write-Host 'Baixando Android Platform-Tools oficial do Google (8 MB)...'
        $temp = Join-Path ([IO.Path]::GetTempPath()) ('switchphone-' + [guid]::NewGuid().ToString('N'))
        [void](New-Item -ItemType Directory -Path $temp)
        try {
            $archive = Join-Path $temp 'platform-tools.zip'
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.google.com/android/repository/platform-tools_r37.0.1-win.zip' -OutFile $archive
            if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '45f4d63113e895ebde0c90f194099a4676b6ac653bd28d54314a9e022bbc1a99') { throw 'E_HASH' }
            if (Test-Path -LiteralPath $toolRoot) { throw 'E_CACHE' }
            Expand-Archive -LiteralPath $archive -DestinationPath $toolRoot
        } finally { Remove-Item -LiteralPath $temp -Recurse -Force }
    }
    $hashes = @{
        'adb.exe' = 'b4a6b455702684652cccf7b46258b29e653538904359a58fd4931cf3ef286b3f'
        'AdbWinApi.dll' = 'c1d653030b4bde65d3e07e4d0b0979e17be56df1436cdd15528630f27808050d'
        'AdbWinUsbApi.dll' = '0710e894d9b40f71a670c13c694079d564c92c1279da382cfe4850983aaebe1b'
    }
    foreach ($file in $hashes.Keys) {
        $path = Join-Path (Join-Path $toolRoot 'platform-tools') $file
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'E_HASH' }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hashes[$file]) { throw 'E_HASH' }
    }
    return $adb
}

function Invoke-BondCapture {
    param([string]$AdbPath, [ValidateRange(1,180)][int]$Seconds = 90)
    $device = Invoke-AdbShort $AdbPath '-d get-state'
    if ($device.Code -ne 0 -or $device.Text -cne 'device') { throw 'E_USB' }
    $bt = Invoke-AdbShort $AdbPath '-d shell pidof com.android.bluetooth'
    if ($bt.Code -ne 0 -or $bt.Text -notmatch '^\d{1,8}$') { throw 'E_BT_PID' }
    $clock = Invoke-AdbShort $AdbPath '-d shell date +%s.%N'
    if ($clock.Code -ne 0 -or $clock.Text -notmatch '^\d{9,12}\.\d{9}$') { throw 'E_CLOCK' }
    # Android 16 prefixes this tag with Utils.TAG_PREFIX_BLUETOOTH ("Bluetooth").
    # Keep the legacy tag too; both remain restricted to the Bluetooth process.
    $arguments = '-d logcat --pid=' + $bt.Text + ' -b main -v raw -T ' + $clock.Text + ' -s BluetoothBondStateMachine:I BondStateMachine:I *:S'
    $process = Start-AdbProcess $AdbPath $arguments
    $events = New-Object 'System.Collections.Generic.List[object]'
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $ended = $false
    $linesRead = 0
    $unmatchedLines = 0
    try {
        # Never write raw stdout/stderr to the terminal, disk or report.
        $errorTask = $process.StandardError.ReadToEndAsync()
        $lineTask = $process.StandardOutput.ReadLineAsync()
        Write-Host 'COLETA INICIADA: tente agora parear o celular com o Switch.'
        Write-Host 'Aguardando ate 90 segundos. Apenas codigos numericos serao salvos.'
        while ($watch.Elapsed.TotalSeconds -lt $Seconds -and $events.Count -lt 64) {
            if (-not $lineTask.IsCompleted) { Start-Sleep -Milliseconds 100; continue }
            $line = $lineTask.GetAwaiter().GetResult()
            if ($null -eq $line) { $ended = $true; break }
            if ($line.Length -gt 0) { $linesRead++ }
            $event = Convert-BondLine $line ([int][Math]::Floor($watch.Elapsed.TotalSeconds))
            if ($null -ne $event) {
                [void]$events.Add($event)
                Write-Host ('Evento: status={0}, estado nativo={1}, hciReason={2}' -f $event.status,$event.native_bond_state,$event.hci_reason)
                if ($event.native_bond_state -ne 1) { break }
            } elseif ($line.Length -gt 0) { $unmatchedLines++ }
            $lineTask = $process.StandardOutput.ReadLineAsync()
        }
        if ($ended -and $process.WaitForExit(1000) -and $process.ExitCode -ne 0) { throw 'E_LOGCAT' }
    } finally {
        $watch.Stop()
        if (-not $process.HasExited) { $process.Kill(); [void]$process.WaitForExit(1000) }
        $process.Dispose()
    }
    $outcome = 'no_events'
    if ($events.Count -gt 0) { $outcome = 'bond_events' }
    elseif ($ended) { $outcome = 'stream_ended' }
    [pscustomobject][ordered]@{
        format = 'switchphone-bond-codes-v1'
        collector_version = '1.1.0'
        duration_seconds = [int][Math]::Floor($watch.Elapsed.TotalSeconds)
        outcome = $outcome
        lines_read = $linesRead
        unmatched_lines = $unmatchedLines
        events = @($events.ToArray())
    }
}

function Start-Collector {
    param([string]$Directory)
    $messages = @{
        E_USB = 'USB nao autorizado/encontrado. Ative Depuracao USB, desbloqueie o celular e aceite a autorizacao. Deixe apenas um celular USB conectado.'
        E_BT_PID = 'Processo Bluetooth nao encontrado. Ative Bluetooth no celular. O fabricante pode usar outro processo.'
        E_CLOCK = 'O Android nao forneceu o horario necessario. Nenhum log antigo foi coletado.'
        E_ADB_TIMEOUT = 'O ADB nao respondeu em 15 segundos. Reconecte o cabo e execute novamente.'
        E_ADB_START = 'Nao foi possivel executar o ADB. Confira o arquivo e as restricoes do Windows.'
        E_HASH = 'A verificacao SHA-256 das ferramentas falhou. Nada desse conjunto sera executado. Baixe e extraia o coletor em uma pasta nova.'
        E_CACHE = 'Cache incompleto. Extraia o coletor em uma pasta nova e execute novamente.'
        E_LOGCAT = 'O Android recusou/encerrou a leitura. Nenhum motivo foi inventado. Envie apenas esta mensagem.'
    }
    try {
        Write-Host 'SwitchPhone coletor USB 1.1.0 - filtro Android 16 e legado'
        $adb = Get-VerifiedAdb $Directory
        Write-Host 'Deixe Bluetooth do PC desligado e o do celular ligado. Conecte o cabo USB.'
        Write-Host 'Ative Depuracao USB nas opcoes do desenvolvedor e aceite a autorizacao no celular.'
        # Start the ordinary ADB USB authorization dialog before waiting for Enter.
        [void](Invoke-AdbShort $adb '-d get-state')
        [void](Read-Host 'Pressione Enter quando estiver pronto para tentar o Switch')
        $report = Invoke-BondCapture $adb
        $filename = 'switchphone-bluetooth-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,4) + '.json'
        $path = Join-Path $Directory $filename
        $report | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $path -Encoding UTF8
        Write-Host ('Pronto. Envie o arquivo ' + $filename + ' desta pasta, junto do Diagnostico do app.')
        if ($report.events.Count -eq 0) { Write-Host 'Nenhum callback encontrado. Isso nao identifica a causa; o fabricante pode nao emitir essa linha.' }
        return 0
    } catch {
        $code = $_.Exception.Message
        if ($messages.ContainsKey($code)) { Write-Host $messages[$code] }
        else { Write-Host 'Falha local no coletor/download. Confira Internet e permissao de escrita; extraia em uma pasta nova. Nenhum log bruto foi salvo.' }
        return 1
    }
}

if ($MyInvocation.InvocationName -ne '.') { exit (Start-Collector $PSScriptRoot) }
