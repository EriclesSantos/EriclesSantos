# Abrir a continuação no Windows

Este pacote leva o código e um resumo da tarefa. Ele não muda automaticamente a sessão atual nem concede acesso remoto ao computador.

1. Extraia o ZIP inteiro para uma pasta do Windows.
2. Abra a pasta **switchphone-local** em uma sessão local do Codex, no seu Windows. Abrir somente o chat na nuvem continua sem dar acesso ao USB.
3. Conecte o Switch e use **DBI → Run MTP responder** para expor o cartão SD.
4. Cole esta mensagem na sessão local:

> Leia CONTEXTO-PARA-CODEX.md e continue a atualização do MissionControl que autorizei. Verifique o acesso real ao Switch pelo DBI/MTP, confirme a compatibilidade, faça backup dos arquivos atuais, use o pacote oficial e confira a transferência. Não atualize o firmware do console nem instale exefs.nsp como jogo.

O resumo contém as versões, os testes anteriores, as fontes oficiais, o hash do pacote e o que ainda falta validar. A atualização ainda não foi feita. Se você não tiver um Codex com execução local disponível no Windows, baixar este ZIP sozinho não cria essa execução.

O projeto está em **switchphone-controller**. O APK existente e o manifesto MissionControl estão em **referencias**. A chave privada de assinatura não está incluída. Nenhum coletor novo foi acrescentado, nenhum script de atualização automática será executado ao abrir o pacote.
