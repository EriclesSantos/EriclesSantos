#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
java com.sun.tools.javac.Main -d "$out" android-app/app/src/main/java/com/switchphone/controller/ControllerState.java android-app/app/src/main/java/com/switchphone/bluetooth/DiagnosticDescriptor.java android-app/app/src/main/java/com/switchphone/protocol/NintendoDescriptor.java android-app/app/src/main/java/com/switchphone/protocol/NintendoProtocol.java tests/ControllerStateTest.java tests/NintendoProtocolTest.java
java -cp "$out" ControllerStateTest
java -cp "$out" NintendoProtocolTest
