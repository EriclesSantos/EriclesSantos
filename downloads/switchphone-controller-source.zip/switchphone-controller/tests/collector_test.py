#!/usr/bin/env python3
"""Run with Python 3 and pwsh. Uses a fake ADB process; never a real phone."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PWSH = os.environ.get('SWITCHPHONE_PWSH', 'pwsh')
SCRIPT = ROOT / 'scripts/windows/Collect-Bluetooth.ps1'
SENTINEL = 'PRIVATE_FIXTURE_MUST_NOT_LEAVE_MEMORY'

FAKE = r'''#!/usr/bin/env python3
import json, os, sys, time
args = sys.argv[1:]
case = os.environ['SWITCHPHONE_ADB_CASE']
with open(os.environ['SWITCHPHONE_ADB_ARGS'], 'a') as out:
    out.write(json.dumps(args)+'\n')
print('PRIVATE_FIXTURE_MUST_NOT_LEAVE_MEMORY AA:BB:CC:DD:EE:FF key=123456', file=sys.stderr)
if args == ['-d', 'get-state']:
    if case == 'unauthorized': sys.exit(1)
    print('device')
elif args == ['-d', 'shell', 'pidof', 'com.android.bluetooth']:
    print('1234;BAD' if case == 'bad_pid' else '1234')
elif args == ['-d', 'shell', 'date', '+%s.%N']:
    print('bad-clock' if case == 'bad_clock' else '1792000000.123456789')
elif args[:2] == ['-d', 'logcat']:
    if case == 'logcat_error': sys.exit(1)
    if case == 'no_events':
        print('PRIVATE_FIXTURE_MUST_NOT_LEAVE_MEMORY', flush=True)
        print('bondStateChangeCallback: Status: 999 Address: secret newState: 0 hciReason: 999', flush=True)
        time.sleep(5)
    elif case == 'flood':
        for _ in range(200):
            print('bondStateChangeCallback: Status: 0 Address: XX:XX:XX:XX:EE:FF newState: 1 hciReason: 0', flush=True)
        time.sleep(5)
    else:
        print('bondStateChangeCallback: Status: 0 Address: AA:BB:CC:DD:EE:FF newState: 1 hciReason: 0', flush=True)
        print('PRIVATE_FIXTURE_MUST_NOT_LEAVE_MEMORY', flush=True)
        print('bondStateChangeCallback: Status: 1 Address: AA:BB:CC:DD:EE:FF newState: 0 hciReason: 5', flush=True)
        time.sleep(5)
else: sys.exit(3)
'''


def psquote(value):
    return "'" + str(value).replace("'", "''") + "'"


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='switchphone-collector-')
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.fake = self.folder / 'fake-adb'
        self.fake.write_text(FAKE)
        self.fake.chmod(0o755)

    def run_case(self, case):
        output = self.folder / 'numeric.json'
        calls = self.folder / 'args.jsonl'
        runner = self.folder / 'run.ps1'
        runner.write_text(
            '. ' + psquote(SCRIPT) + '\ntry {\n'
            '$result = Invoke-BondCapture ' + psquote(self.fake) + ' -Seconds 1\n'
            '$result | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 '
            + psquote(output) + '\n} catch { Write-Host $_.Exception.Message; exit 2 }\n')
        env = dict(os.environ, SWITCHPHONE_ADB_CASE=case, SWITCHPHONE_ADB_ARGS=str(calls))
        process = subprocess.run([PWSH, '-NoLogo', '-NoProfile', '-File', str(runner)],
                                 env=env, capture_output=True, text=True, timeout=15)
        text = process.stdout + process.stderr
        self.assertNotIn(SENTINEL, text)
        self.assertNotIn('AA:BB:CC:DD:EE:FF', text)
        self.assertNotIn('key=123456', text)
        data = json.loads(output.read_text(encoding='utf-8-sig')) if output.exists() else None
        if data is not None:
            saved = output.read_text(encoding='utf-8-sig')
            self.assertNotIn(SENTINEL, saved)
            self.assertNotIn('AA:BB:CC:DD:EE:FF', saved)
            for event in data['events']:
                self.assertEqual(set(event), {'elapsed_seconds','status','native_bond_state','hci_reason'})
                self.assertTrue(all(isinstance(v, int) for v in event.values()))
        argv = [json.loads(line) for line in calls.read_text().splitlines()]
        return process, data, argv

    def test_terminal_bond_and_privacy(self):
        process, data, argv = self.run_case('normal')
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(data['outcome'], 'bond_events')
        self.assertEqual([(e['native_bond_state'],e['hci_reason']) for e in data['events']], [(1,0),(0,5)])
        self.assertEqual(argv[-1], ['-d','logcat','--pid=1234','-b','main','-v','raw','-T',
                                   '1792000000.123456789','-s','BondStateMachine:I','*:S'])
        self.assertTrue(all('-c' not in command for command in argv))

    def test_empty_capture_expires(self):
        process, data, _ = self.run_case('no_events')
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(data['outcome'], 'no_events')
        self.assertEqual(data['events'], [])
        self.assertLessEqual(data['duration_seconds'], 2)

    def test_bounded_event_count(self):
        process, data, _ = self.run_case('flood')
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(len(data['events']), 64)

    def test_preflight_and_stream_failures(self):
        for case, code, count in [('unauthorized','E_USB',1),('bad_pid','E_BT_PID',2),
                                   ('bad_clock','E_CLOCK',3),('logcat_error','E_LOGCAT',4)]:
            with self.subTest(case=case):
                # Each subcase uses separate call/output files.
                for name in ('args.jsonl','numeric.json'):
                    (self.folder / name).unlink(missing_ok=True)
                process, data, argv = self.run_case(case)
                self.assertEqual(process.returncode, 2)
                self.assertIn(code, process.stdout)
                self.assertIsNone(data)
                self.assertEqual(len(argv), count)

    def test_parser_rejects_unexpected_content(self):
        runner = self.folder / 'parser.ps1'
        runner.write_text('. ' + psquote(SCRIPT) + r'''
$valid = Convert-BondLine 'bondStateChangeCallback: Status: 0 Address: XX:XX:XX:XX:EE:FF newState: 2 hciReason: -1' 3
if ($null -eq $valid -or $valid.hci_reason -ne -1 -or $valid.elapsed_seconds -ne 3) { throw 'valid event lost' }
$invalid = @(
    'key=123456',
    'bondStateChangeCallback: Status: 256 Address: private newState: 0 hciReason: 0',
    'bondStateChangeCallback: Status: 1 Address: private newState: 3 hciReason: 0',
    'bondStateChangeCallback: Status: 1 Address: private newState: 0 hciReason: 256',
    'bondStateChangeCallback: Status: 1 Address: private newState: 0 hciReason: 5 key=123456',
    "bondStateChangeCallback: Status: 1 Address: private`nkey=123456 newState: 0 hciReason: 5"
)
foreach ($line in $invalid) { if ($null -ne (Convert-BondLine $line 0)) { throw 'unexpected event accepted' } }
Write-Host 'Parser checks passed'
''')
        process = subprocess.run([PWSH, '-NoLogo', '-NoProfile', '-File', str(runner)],
                                 capture_output=True, text=True, timeout=10)
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
