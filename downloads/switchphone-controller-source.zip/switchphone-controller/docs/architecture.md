# Arquitetura 0.2.2

Um módulo Android Java, minSdk 28, compile/target 35, sem bibliotecas de runtime, Internet ou busca ativa de aparelhos.

- MainActivity: navegação, permissões e resultados Android, janela em primeiro plano, binder do serviço, prazo visível e diagnóstico copiável.
- bluetooth/PairingFlow: máquina de estados Java pura. Cada pedido é emitido uma vez, somente na etapa esperada e com a Activity retomada e com foco. Callbacks duplicados/tardios após cancelamento/falha não reabrem o fluxo.
- bluetooth/HidForegroundService: eleva a importância do processo para manter o perfil durante o diálogo Bluetooth remoto. Há notificação/ação Encerrar, prazo de pareamento e START_NOT_STICKY. Não procura dispositivos. O serviço começa depois das confirmações, quando permissões já existem, e termina ao encerrar/falhar/expirar. Se a conexão completar com a UI em segundo plano, há cinco segundos para retornar antes de fechar a sessão. Não exige solicitação de notificações para a notificação obrigatória do serviço.
- bluetooth/HidSession: proxy HID, callbacks reais, registro, reconexão, timeouts e protocolo. Enlace confirmado libera comandos; confirmação do modo Nintendo determina pontos verdes. Fase NEGOTIATING também permite entradas para evitar bloquear L+R.
- bluetooth/IdentityLease: muda o nome uma vez por aquisição e mantém recuperação persistente; adquirir de novo não restaura/renomeia durante a tentativa.
- controller/InputRouter: estados separados de toque local e transporte. Nem relatórios periódicos leem o estado do teste local.
- controller/PairingPulse: sobrepõe L+R temporariamente ao snapshot, sem mudar os botões mantidos pelos dedos.
- controller/ControllerState, layouts/ControllerView e layouts/ConnectionIndicator: comandos, multitoque/Canvas e sinais visuais sem loop de renderização permanente.
- protocol/NintendoProtocol/Descriptor: comandos Nintendo parciais e SPI virtual; DiagnosticDescriptor fornece modo PC genérico.
- settings/Preferences e haptics/Haptics: ajustes e vibração local.

Sequência: permissões → Bluetooth ligado → nome observado → diálogo de visibilidade → Activity retomada/com foco → serviço foreground → registro HID → aguardar host (até 120 s) → negociação Nintendo (até 45 s). Confirmar L+R funciona quando o enlace já existe, inclusive em 3F antes da negociação completa.

Diálogos anteriores ao registro não derrubam um perfil ainda inexistente. Durante vínculo remoto, o serviço preserva a importância do processo e a Activity não encerra a tentativa ao ser coberta. A sessão segue vinculada ao ciclo de vida da Activity e é cancelada se ela for destruída; não é restaurada automaticamente após morte do processo. Eventos de vínculo Android são observados sem ler endereço/nome do host e nunca simulam confirmação de entrada em jogo.

Após vínculo com um único Nintendo Switch conhecido, a UI solicita uma conexão HID uma única vez; não espera indefinidamente por conexão de entrada. Novo evento de vínculo usa o dispositivo confirmado pelo Android. Mais de um console conhecido exige escolha manual. Callbacks de conexão duplicados não reiniciam os timeouts do transporte.
