# Arquitetura 0.2.4

Um módulo Android Java, minSdk 28, compile/target 35, sem bibliotecas de runtime, Internet ou busca ativa de aparelhos.

- MainActivity: navegação, permissões e resultados Android, janela em primeiro plano, binder do serviço, prazo visível e diagnóstico copiável.
- bluetooth/PairingFlow: máquina de estados Java pura. Cada pedido é emitido uma vez, somente na etapa esperada e com a Activity retomada e com foco. Callbacks duplicados/tardios após cancelamento/falha não reabrem o fluxo.
- bluetooth/HidForegroundService: eleva a importância do processo para manter o perfil durante o diálogo Bluetooth remoto. Há notificação/ação Encerrar, prazo de pareamento e START_NOT_STICKY. Não procura dispositivos. O serviço começa depois das confirmações, quando permissões já existem, e termina ao encerrar/falhar/expirar. Se a conexão completar com a UI em segundo plano, há cinco segundos para retornar antes de fechar a sessão. Não exige solicitação de notificações para a notificação obrigatória do serviço.
- bluetooth/BondFailure: descrição de metadados opcionais Android de remoção. A chave interna de extra é lida como string por Intent.getIntExtra; não chama APIs ocultas. Ausência/códigos desconhecidos permanecem explícitos e REMOVED também é tratado como fallback genérico. Android 16+ pode emitir KEY_MISSING protegido; recebê-lo apenas acrescenta observação, sem ler chaves ou alterar a política de conexão.
- bluetooth/BondMonitor: vínculo separado do canal HID. Nenhum evento de vínculo inicia conexão; perda de vínculo é terminal até nova ação Parear. Abertura manual requer vínculo estável por 5 s e só pode ocorrer uma vez por tentativa.
- bluetooth/HidSession: proxy HID, callbacks reais, registro, reconexão, timeouts e protocolo. Enlace confirmado libera comandos; confirmação do modo Nintendo determina pontos verdes. Fase NEGOTIATING também permite entradas para evitar bloquear L+R.
- bluetooth/IdentityLease: muda o nome uma vez por aquisição e mantém recuperação persistente; adquirir de novo não restaura/renomeia durante a tentativa.
- controller/InputRouter: estados separados de toque local e transporte. Nem relatórios periódicos leem o estado do teste local.
- controller/PairingPulse: sobrepõe L+R temporariamente ao snapshot, sem mudar os botões mantidos pelos dedos.
- controller/ControllerState, layouts/ControllerView e layouts/ConnectionIndicator: comandos, multitoque/Canvas e sinais visuais sem loop de renderização permanente.
- protocol/NintendoProtocol/Descriptor: comandos Nintendo parciais e SPI virtual; DiagnosticDescriptor fornece modo PC genérico.
- settings/Preferences e haptics/Haptics: ajustes e vibração local.

Sequência: permissões → Bluetooth ligado → nome observado → diálogo de visibilidade → Activity retomada/com foco → serviço foreground → registro HID → aguardar host (até 120 s) → negociação Nintendo (até 45 s). Confirmar L+R funciona quando o enlace já existe, inclusive em 3F antes da negociação completa.

Diálogos anteriores ao registro não derrubam um perfil ainda inexistente. Durante vínculo remoto, o serviço preserva a importância do processo e a Activity não encerra a tentativa ao ser coberta. A sessão segue vinculada ao ciclo de vida da Activity e é cancelada se ela for destruída; não é restaurada automaticamente após morte do processo. Eventos protegidos de vínculo são filtrados pelo dispositivo escolhido ou pelo nome exato Nintendo Switch, sem ler/publicar endereços. Eventos de outros aparelhos são ignorados e nunca simulam confirmação de entrada em jogo. O erro terminal continua visível ao sair/voltar ao app.

Após vínculo, a UI continua aguardando a conexão HID iniciada pelo host, com prazo de visibilidade original. BOND_BONDED não chama connect, não completa PairingFlow e não habilita L+R. BOND_NONE após BONDING/BONDED encerra a sessão, sem reabrir prompts. Em vínculo estável, o usuário pode usar Abrir enlace HID (Reconectar no PC); a chamada confere novamente BOND_BONDED e READY no transporte. Mais de um console conhecido exige escolha manual. Callbacks duplicados não reiniciam timeouts.

O diagnóstico distingue estado atual de marcos da tentativa. Antes de fechar o proxy preserva se houve registro/canal, último callback Android e contagem de solicitações do host/envios aceitos pelo Android. Não guarda payloads nem mede se o console/jogo consumiu entradas. A confirmação anterior do nome é preservada mesmo após a restauração.

Consulta getBondedDevices e o estado anterior trazido por broadcast usam seedExisting, sem simular um callback BONDED novo. O diagnóstico separa snapshot do vínculo salvo, callback efetivamente recebido, código opcional de perda e sinal de chave ausente. Estes campos não habilitam botões, não iniciam conexões, não removem vínculos e não recuperam sessões terminais. Metadados opcionais não são pré-requisito de funcionamento.
