# Arquitetura

Um módulo Android Java, minSdk 28, compile/target 35, sem dependências de runtime, Internet ou serviço de fundo.

- MainActivity: navegação, permissões, pareamento em um botão, resultados das telas Android, mensagens, diagnóstico e bloqueio de inputs.
- layouts/ControllerView: Canvas vetorial, propriedade independente de ponteiros, diagonais, analógicos e estilo cinza rebaixado quando inativo; sem loop de desenho permanente.
- layouts/ConnectionIndicator: três LEDs; animação apenas durante operações pendentes.
- controller/ControllerState: comandos canônicos, normalização de eixos e relatório PC. Layout visual não altera o modo Bluetooth.
- bluetooth/HidSession: estados explícitos, callbacks reais, registro, reconexão, timeouts, falhas e limpeza. Confirmações nunca são simuladas.
- bluetooth/IdentityLease: nome temporário Pro Controller e recuperação persistida, inclusive após queda de processo. Confirma restauração antes de apagar o marcador; pequenas gravações síncronas são necessárias antes da mudança global de nome.
- protocol/NintendoProtocol: serialização pura Java, respostas limitadas, memória/calibração virtual e comandos Nintendo parciais.
- protocol/NintendoDescriptor e bluetooth/DiagnosticDescriptor: contratos separados dos dois modos.
- settings/Preferences e haptics/Haptics: ajustes persistidos e vibração local.

Operações Bluetooth são pedidos Binder e callbacks no main looper. O stream Nintendo 0x30 usa intervalos de 17 ms enquanto conectado e negociado; é interrompido ao desconectar/encerrar. Não há polling ou serviço de fundo. Mensagens repetidas de rumble são deduplicadas para evitar inundar UI/log.

Ao sair da Activity a sessão é encerrada. Diálogos de sistema podem interrompê-la; seus resultados retomam o pareamento. Timeouts e callbacks tardios têm proteção para evitar reativar um perfil após erro. O histórico de diagnóstico fica apenas em memória.
