# Compatibilidade

| Componente | Estado |
|---|---|
| Android 9+ / HID Device clássico | API alvo; depende de fabricante/stack |
| Galaxy A23, A14/A15, Moto G, Redmi Note, POCO | Não testados |
| Windows/Linux/macOS e jogos | Modo HID genérico implementado; não testados fisicamente; não é XInput |
| Switch V1/V2/Lite/OLED com Atmosphère/MissionControl | Emulação Pro Controller parcial implementada; nenhum modelo validado |
| Bluetooth padrão e protocolo Nintendo | Código e contratos automatizados; pareamento/negociação reais não testados |
| IMU/NFC/rumble do jogo | Não implementados, pedidos recusados |
| Multiplayer/desempenho/latência/autonomia | Não testados/medidos |

MAC/VID/PID reais dependem do Android. Nome é temporariamente Pro Controller no modo Nintendo, com tentativa de restauração ao encerrar. Modos 31/NFC e pareamento manual por LTK não são implementados. Hosts que exijam comandos ausentes podem falhar.

Anotar versões Android/HOS/Atmosphère/MissionControl, modelo, último estágio do diagnóstico, entradas em jogo, reconexão e liberação. Pontos verdes não demonstram aceitação das entradas pelo jogo. Comece com um telefone; não declarar suporte a quatro jogadores sem teste progressivo.
