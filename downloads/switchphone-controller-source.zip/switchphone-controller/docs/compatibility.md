# Compatibilidade

| Componente | Estado |
|---|---|
| Android 9+ / HID Device clássico | API alvo; depende de fabricante/stack |
| Galaxy A23, A14/A15, Moto G, Redmi Note, POCO | Não testados |
| Windows + Xiaomi 2511FPC34G/Android 16, app 0.2.4 | Reconhecido como SwitchPhone Gamepad, status OK em joy.cpl; usuário confirmou resposta às entradas. Windows/build não informado. Não é validação em jogo nem XInput |
| Linux/macOS e jogos específicos no Windows | Não testados fisicamente |
| Xiaomi 2511FPC34G, Android 16/API 36 + Switch Lite/CNX com arquivos MissionControl no SD, relatos 0.2.2–0.2.4 | Registro HID confirmado; vínculo removido antes do canal HID. Na 0.2.3, vínculo pré-existente caiu sem connect de saída. Não funcional nesse teste. HOS 21.1.0/Atmosphère 1.10.1/emuMMC E confirmados; módulo MissionControl v0.14.2 oficial identificado por hash; teste limpo 0.2.4 iniciou vínculo e falhou em 8 s, motivo Android 0; conteúdo dos patches e execução MissionControl ainda a conferir |
| Switch V1/V2/OLED | Emulação parcial; não testados |
| Bluetooth padrão e protocolo Nintendo | Contratos automatizados; tentativa real falhou antes do canal HID. Negociação/entradas em jogo não confirmadas |
| IMU/NFC/rumble do jogo | Não implementados, pedidos recusados |
| Multiplayer/desempenho/latência/autonomia | Não testados/medidos |

MAC/VID/PID reais dependem do Android. Nome é temporariamente Pro Controller no modo Nintendo, com tentativa de restauração ao encerrar. Modos 31/NFC e pareamento manual por LTK não são implementados. Hosts que exijam comandos ausentes podem falhar.

Anotar versões Android/HOS/Atmosphère/MissionControl, modelo, último estágio do diagnóstico, entradas em jogo, reconexão e liberação. Pontos verdes não demonstram aceitação das entradas pelo jogo. Comece com um telefone; não declarar suporte a quatro jogadores sem teste progressivo.

Na 0.2.2, permitir o vínculo não basta para pontos verdes. Entradas são liberadas após enlace HID para confirmar L+R; modo Nintendo negociado é condição separada. Teste local de toque não é teste Bluetooth. Serviço foreground com tipo connectedDevice pode depender das restrições do fabricante; falhas são mostradas no diagnóstico.

A 0.2.3 remove a conexão de saída automática imediata após vínculo, encerra ao observar perda do vínculo do host e mantém marcos no diagnóstico após a limpeza. Isso elimina uma disputa possível no código, mas não prova que essa seja a causa física da remoção observada. Bluetooth/classificação/autenticação e patches de MissionControl compatíveis continuam relevantes. Não é possível inferir o iniciador ou motivo da remoção apenas com BOND_NONE.

Notas oficiais: MissionControl [v0.14.1](https://github.com/ndeadly/MissionControl/releases/tag/v0.14.1) adicionou suporte ao HOS 21.1.0. Isso não identifica a versão instalada pelo usuário nem comprova que seus patches estejam ativos.

A ocorrência 0.2.3 mostra registro HID, nenhum callback de conexão, nenhum pedido do host e perda de vínculo salvo aos 7 s. Logo a hipótese de disputa por connect não explica esta ocorrência. CNX e arquivos do módulo/boot2 no SD foram informados; presença/correspondência dos patches e execução do módulo ainda não foram verificadas. Android 16 não é declarado suportado funcionalmente com esse console apenas porque a API registra o perfil.

Teste de controle genérico no PC aprovado no escopo relatado pelo usuário em 2026-10-14. Isso confirma uma sessão HID e entradas no Windows para esse par celular/computador, sem comprovar todos os controles, jogos ou operação prolongada. A captura mostra SwitchPhone Gamepad no joy.cpl com status OK. Nenhuma imagem foi copiada para o repositório, preservando outros dados visíveis no desktop.

## Identificação do módulo enviado
O exefs.nsp enviado pelo usuário corresponde byte a byte ao módulo da release oficial MissionControl v0.14.2: 166310 bytes, SHA-256 4a21c9d7333d6f7944f88c2067d49c7fb5a7506e0f83fe5898c7d9abb9ce48fa. Foi apenas lido/comparado, não executado nem redistribuído. README v0.14.2 exige AMS >=1.10.2 especificamente no HOS 21.2.0+; o usuário informou HOS 21.1.0/AMS 1.10.1. Identificar o módulo não comprova sua execução nem o conteúdo dos patches no console. Referências dos arquivos bluetooth_patches e btm_patches foram preparadas para a próxima conferência.

## Conferência do ZIP de patches enviado

O ZIP btm_patches.zip contém ambas as pastas: bluetooth_patches (30 arquivos IPS) e btm_patches (29 arquivos IPS). Os 59 arquivos correspondem byte a byte aos do pacote oficial MissionControl v0.14.2; não há arquivos esperados ausentes, extras ou com conteúdo diferente nesse conjunto recebido. Não foram extraídos para execução nem redistribuídos.

Junto do exefs.nsp já identificado, isso confirma o conteúdo enviado do módulo e desses dois conjuntos de patches. Não confirma execução do módulo, aplicação de patches em memória ou compatibilidade do pareamento Android 16/Switch.

Próximo dado solicitado: estado MissionControl no Hekate Toolbox → Background services imediatamente após reiniciar no Atmosphère e antes de alterar botões. O código consultado do Hekate Toolbox consulta pmdmntGetProcessId ao abrir a tela, diferente de verificar apenas boot2. Alterar a chave de um módulo requires_reboot pode atualizar o estado visual segundo o flag; por isso a observação deve ser feita em abertura nova após reinício, antes de tocar no botão.

Fonte inspecionada: https://github.com/WerWolv/Hekate-Toolbox/blob/c3a9be6158e18267564c6785948d24d84fa3f683/source/gui/gui_sysmodule.cpp . Foi lida para entender a indicação; não foi copiado código nem executado o aplicativo Switch neste ambiente. Uma indicação Off também pode depender de sucesso de acesso à API do gerenciador, e deve ser interpretada com o contexto da execução.
