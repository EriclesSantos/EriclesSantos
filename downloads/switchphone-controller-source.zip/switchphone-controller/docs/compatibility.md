# Compatibilidade

| Componente | Estado |
|---|---|
| Android 9+ / HID Device clássico | API alvo; depende de fabricante/stack |
| Galaxy A23, A14/A15, Moto G, Redmi Note, POCO | Não testados |
| Windows/Linux/macOS e jogos | Modo HID genérico implementado; não testados fisicamente; não é XInput |
| Switch Lite com MissionControl ativo, relato 0.2.1 | Diálogo Android de vínculo observado; reconhecimento/jogo não confirmados. Novo teste 0.2.2 pendente |
| Switch V1/V2/OLED | Emulação parcial; não testados |
| Bluetooth padrão e protocolo Nintendo | Código e contratos automatizados; pareamento/negociação reais não testados |
| IMU/NFC/rumble do jogo | Não implementados, pedidos recusados |
| Multiplayer/desempenho/latência/autonomia | Não testados/medidos |

MAC/VID/PID reais dependem do Android. Nome é temporariamente Pro Controller no modo Nintendo, com tentativa de restauração ao encerrar. Modos 31/NFC e pareamento manual por LTK não são implementados. Hosts que exijam comandos ausentes podem falhar.

Anotar versões Android/HOS/Atmosphère/MissionControl, modelo, último estágio do diagnóstico, entradas em jogo, reconexão e liberação. Pontos verdes não demonstram aceitação das entradas pelo jogo. Comece com um telefone; não declarar suporte a quatro jogadores sem teste progressivo.

Na 0.2.2, permitir o vínculo não basta para pontos verdes. Entradas são liberadas após enlace HID para confirmar L+R; modo Nintendo negociado é condição separada. Teste local de toque não é teste Bluetooth. Serviço foreground com tipo connectedDevice pode depender das restrições do fabricante; falhas são mostradas no diagnóstico.
