# Compatibilidade

| Componente | Estado |
|---|---|
| Android 9+ / HID Device clássico | API alvo; depende de fabricante/stack |
| Galaxy A23, A14/A15, Moto G, Redmi Note, POCO | Não testados |
| Windows/Linux/macOS e jogos | Modo HID genérico implementado; não testados fisicamente; não é XInput |
| Xiaomi 2511FPC34G, Android 16/API 36 + Switch Lite/MissionControl ativo, relato 0.2.2 | Registro HID confirmado; vínculo criado/removido antes do canal HID. Não funcional nesse teste. HOS 21.1.0/Atmosphère 1.10.1/emuMMC E confirmados; versão MissionControl ainda não informada; novo teste 0.2.3 pendente |
| Switch V1/V2/OLED | Emulação parcial; não testados |
| Bluetooth padrão e protocolo Nintendo | Contratos automatizados; tentativa real falhou antes do canal HID. Negociação/entradas em jogo não confirmadas |
| IMU/NFC/rumble do jogo | Não implementados, pedidos recusados |
| Multiplayer/desempenho/latência/autonomia | Não testados/medidos |

MAC/VID/PID reais dependem do Android. Nome é temporariamente Pro Controller no modo Nintendo, com tentativa de restauração ao encerrar. Modos 31/NFC e pareamento manual por LTK não são implementados. Hosts que exijam comandos ausentes podem falhar.

Anotar versões Android/HOS/Atmosphère/MissionControl, modelo, último estágio do diagnóstico, entradas em jogo, reconexão e liberação. Pontos verdes não demonstram aceitação das entradas pelo jogo. Comece com um telefone; não declarar suporte a quatro jogadores sem teste progressivo.

Na 0.2.2, permitir o vínculo não basta para pontos verdes. Entradas são liberadas após enlace HID para confirmar L+R; modo Nintendo negociado é condição separada. Teste local de toque não é teste Bluetooth. Serviço foreground com tipo connectedDevice pode depender das restrições do fabricante; falhas são mostradas no diagnóstico.

A 0.2.3 remove a conexão de saída automática imediata após vínculo, encerra ao observar perda do vínculo do host e mantém marcos no diagnóstico após a limpeza. Isso elimina uma disputa possível no código, mas não prova que essa seja a causa física da remoção observada. Bluetooth/classificação/autenticação e patches de MissionControl compatíveis continuam relevantes. Não é possível inferir o iniciador ou motivo da remoção apenas com BOND_NONE.

Notas oficiais: MissionControl [v0.14.1](https://github.com/ndeadly/MissionControl/releases/tag/v0.14.1) adicionou suporte ao HOS 21.1.0. Isso não identifica a versão instalada pelo usuário nem comprova que seus patches estejam ativos.
