# Compatibilidade — 0.2.5

Resultados físicos relatados pelo usuário com APK 0.2.4 em 2026-10-14. A 0.2.5 ainda precisa de instalação/teste físico.

| Componente | Evidência e limite |
|---|---|
| Xiaomi 2511FPC34G, Android 16/API 36, destino PC e Windows | SwitchPhone Gamepad, status OK no joy.cpl; usuário confirmou entradas. Windows/build e inventário completo de botões não informados; jogos e XInput não validados |
| Mesmo telefone/Windows, destino Switch experimental | Pro Controller; callback Android CONNECTED, canal HID aberto, sete envios aceitos pelo Android, L+R enviado. Nenhum GET/SET/Interrupt; NEGOTIATING. Não valida comandos Nintendo ou o Switch |
| Mesmo telefone + Switch Lite 21.1.0/AMS 1.10.1/E, CNX | Tentativas 0.2.2–0.2.4 falharam antes do canal HID. Teste limpo 0.2.4: BONDING aos 38 s, NONE aos 46 s, motivo Android 0; sem BONDED ou callback HID |
| MissionControl desse Switch | Módulo e 59 patches Bluetooth/BTM enviados idênticos ao pacote oficial v0.14.2. Usuário confirmou On no Hekate Toolbox após reiniciar, antes de alterar botões. Aplicação dos patches em memória não inspecionada |
| Outros telefones, Linux/macOS e Switch V1/V2/OLED | Não testados fisicamente |
| IMU/NFC/rumble do jogo/pareamento manual por chaves | Não implementados |
| Multiplayer, jogos, estabilidade, latência/autonomia | Não testados/medidos |

Android 9+ é a API alvo; o perfil HID depende do fabricante. MAC/VID/PID reais são controlados pelo Android. Pro Controller é um nome temporário no destino Nintendo, restaurado ao encerrar. Emulação Nintendo é parcial.

Na 0.2.5, pontos verdes indicam canal HID conectado, inclusive durante NEGOTIATING. Mensagem amarela e diagnóstico informam separadamente negociação Nintendo pendente. ACTIVE exige comando de modo aceito do host; permanece o prazo de negociação de 45 s. Teste local de toque não é teste Bluetooth. Cor verde não confirma consumo das entradas pelo jogo.

No teste Windows com destino Nintendo, vínculo UNKNOWN não contradiz HID CONNECTED: o observador de vínculo desse modo filtra Nintendo Switch, enquanto o host real era o PC. O canal é confirmado pelo callback nativo HID.

A próxima coleta tenta obter status/hciReason nativos via [coletor USB](../scripts/windows/LEIA-ME.txt); o fabricante pode não emitir essa linha. O sucesso dos dois destinos no Windows não identifica a causa da falha com o console.

[MissionControl v0.14.1](https://github.com/ndeadly/MissionControl/releases/tag/v0.14.1) introduziu suporte HOS 21.1.0. O requisito AMS >=1.10.2 do README v0.14.2 é específico do HOS 21.2.0+, diferente do sistema informado. Hashes e investigação em missioncontrol-reference.json e bluetooth-research.md.

## Comparação adicional informada

Usuário relatou falha semelhante com outro celular Galaxy, sem modelo/Android ou log específicos por enquanto. Confirmou que ao menos um controle PS4/PS5 conectou e funcionou diretamente no Switch com MissionControl. Isso demonstra funcionamento básico do console/MC com um controle compatível e desloca o foco para a interoperabilidade app/Android→Switch. Não comprova que todas as verificações específicas para telefones estão corretas nem distingue sozinho falha do app de política de autenticação do host. Uso anterior de PS4/PS5 no Xiaomi testa o telefone como host, diferente do papel HID Device deste app.
