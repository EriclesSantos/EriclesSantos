# Validação 0.2.3 experimental

- assembleRelease e lintRelease: BUILD SUCCESSFUL. Lint: 0 erros, 1 aviso de orientação paisagem fixa (requisito de layout).
- APK release não depurável: versionCode 5, versionName 0.2.3-experimental, minSdk 28, target/compile 35. Alinhamento e assinatura v3 verificados.
- Certificado SHA-256 c706c29aba14d93b44452100f90c36584fafc1efb85bde4ff959ed1183b8e74a, igual à 0.2.1 e 0.2.2. Atualização pode preservar instalação/preferências.
- APK: 111351 bytes; SHA-256 a00ed3a569a4c975524e7c4cfa9caae77701dd75135885becb2affb6798ab835.
- Manifesto mantém Bluetooth CONNECT/ADVERTISE, vibração e serviço foreground connectedDevice. Sem Internet, contatos, chamadas, localização ou varredura Bluetooth.
- Testes JVM aprovados: 28 estado/descritor, 2.157 protocolo Nintendo (incluindo 5.000 pacotes malformados/aleatórios), 126 PairingFlow, 106 isolamento do toque local, 8 pulso L+R e 23 BondMonitor. Total: 2.448 asserções.
- Nova regressão reproduz sequência do log físico: BONDING aos 4 s, BONDED aos 10 s, perda aos 11 s, novos eventos aos 11/20 s. Não há solicitação de saída automática nem reabertura do fluxo após perda. Testa espera de 5 s e uma solicitação explícita, rejeição de duplicatas e marcos preservados.

## Evidência física recebida e limite da conclusão

Relato 0.2.2: Xiaomi 2511FPC34G, Android 16/API 36, Switch Lite com MissionControl declarado ativo. Sistema informado: 21.1.0|AMS 1.10.1|E. Versão MissionControl ainda desconhecida.

Registro HID foi confirmado aos 3 s; vínculo aceito aos 10 s; a aplicação solicitou conexão HID de saída nesse instante; remoção de vínculo observada aos 11 s; nova sequência de vínculo aos 11/20/21 s; timeout aos 25 s. Não há confirmação de canal HID ou entrada em jogo. O evento Android de remoção não identifica iniciador nem motivo, e o log anterior não contava solicitações GET/SET/Interrupt.

A 0.2.3 retira a chamada automática de connect em READY/BONDED para eliminar uma disputa possível com a conexão de entrada do host. Aguarda o prazo original, oferece abertura manual apenas com vínculo aceito há 5 s e termina ao perder o vínculo. Não chama createBond/removeBond e não usa APIs ocultas. Isso não prova que a concorrência tenha causado a falha no telefone do usuário.

Diagnóstico separa estado atual de registro/canal alguma vez observados, preserva última fase/callback e contagens sem payloads, endereços ou chaves. Nome confirmado durante a tentativa permanece registrado após restaurar o nome original. O erro não é substituído por CLOSED ao sair/voltar ao app.

Notas oficiais consultadas: MissionControl v0.14.1 introduz suporte ao HOS 21.1.0; isso não comprova versão instalada ou carregamento dos patches bluetooth/btm. Não foram alterados arquivos do console nem sugerido apagar o banco global de vínculos.

Não executados: testes instrumentados Android, fluxo de diálogos/serviço em telefone real para 0.2.3, pareamento real 0.2.3 ou entrada em jogo. A correção precisa do próximo teste físico. Emulação segue parcial, sem IMU ativo, NFC, rumble do jogo ou pareamento manual com chaves.

Chave e senha permanecem fora do repositório/ZIP. Compilação na máquina atual: /workspace/toolchains/build-switchphone.sh assembleRelease lintRelease; assinatura por scripts/sign-release.sh com caminhos privados. Não se garante remoção do aviso de desenvolvedor desconhecido do Play Protect.
