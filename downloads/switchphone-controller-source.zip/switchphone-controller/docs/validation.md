# Validação 0.2.0 experimental

Build local: Gradle Wrapper 8.9, AGP 8.7.3, Temurin JDK 17.0.16+8, SDK Platform 35 e Build Tools 35.0.0.

- `./gradlew assembleDebug lintDebug`: sucesso após as alterações finais.
- Lint: 0 erros, 1 aviso de orientação fixa em paisagem, mantida por requisito.
- `./tests/run.sh`: 28 asserções de comandos/estado/descritor genérico e 2.157 asserções Nintendo. O parser também processou 5.000 entradas aleatórias/malformadas com semente fixa sem exceções. Os testes Nintendo incluem formato de relatórios, ACK/NACK, identificação virtual, mapeamento de 14 botões, diagonais, eixos de 12 bits/Y invertido, calibração SPI, limites, comandos ausentes e contadores.
- Assinatura APK debug verificada com `apksigner verify --verbose` (v2).
- APK: 117046 bytes, abaixo da meta de 10 MB.
- SHA-256: `d1aa6f0c266b9b021365dbf308b981a4e37416c1694cbfc1327b102d6fb4fd36`.
- Manifesto inspecionado: Bluetooth e vibração; sem Internet ou localização.
- APK e fontes não contêm chaves privadas de assinatura. O APK usa assinatura de desenvolvimento, não assinatura de produção.
- Repositório de perfil existente permaneceu sem alterações.

Não foram executados testes instrumentados Android, emulador, instalação em telefone, interação multitoque real, pareamento físico, leitura num computador nem funcionamento em jogo no Switch. Testes JVM usam fixtures de protocolo e não simulam uma conexão real na interface. A emulação Nintendo é parcial e pode falhar no hardware, especialmente se o host exigir identidade/chaves/comandos não disponíveis. Pontos verdes significam confirmação do transporte e negociação implementada, não aceite de cada botão pelo jogo.

Na máquina de nuvem atual, repita o build com `/workspace/toolchains/build-switchphone.sh assembleDebug lintDebug`. O helper configura JDK/SDK, diretórios graváveis e proxy existente sem desativar TLS. Em outra máquina siga installation.md/Android Studio. Wrapper e JDK tiveram SHA-256 conferido contra distribuições oficiais; SDK usa sdkmanager com verificações padrão.
