# Validação 0.2.1 experimental — distribuição release

- `./gradlew assembleRelease lintRelease`: sucesso com Gradle 8.9, AGP 8.7.3, JDK 17, SDK 35/Build Tools 35.0.0.
- `scripts/sign-release.sh`: alinhamento e assinatura da variante release concluídos; apksigner verify e zipalign -c aprovados.
- AAPT confirma applicationId com.switchphone.controller, versionCode 3, versão 0.2.1-experimental, minSdk 28 e ausência de application-debuggable.
- Manifesto mantém apenas Bluetooth e vibração, sem Internet/localização. Não houve alteração do código de aplicação em relação à 0.2.0 para tentar contornar o Play Protect.
- Certificado próprio CN=SwitchPhone Controller, SHA-256 `c706c29aba14d93b44452100f90c36584fafc1efb85bde4ff959ed1183b8e74a`. Chave privada e senha estão fora do repositório, não incluídas no APK nem nos fontes.
- APK: 74431 bytes. SHA-256 `d53e9b3870c328eadd4bf42039568d369bce39a7d2eb014ee6035f6ee58a001d`.
- Os testes JVM do código mantêm os resultados previamente executados: 28 asserções de estado/descritor e 2.157 asserções Nintendo, incluindo tratamento de 5.000 pacotes malformados/aleatórios. Não há mudança funcional nesta versão de distribuição.

O APK 0.2.0 era um build Android Debug. A captura do usuário informa desenvolvedor/app desconhecido e oferece Installer quand même em Mais detalhes. Isso não comprova detecção de malware nem comprova segurança do aplicativo. Não foi possível determinar a decisão interna do Play Protect. Assinatura própria/release não equivale a revisão Google e não garante remoção do aviso.

Nenhum teste físico Android/PC/Switch, jogo, multitoque real, latência ou autonomia foi concluído nesta máquina. A emulação Nintendo continua parcial. A atualização da assinatura exige remover a versão debug já instalada; preferências locais serão perdidas. O nome do pacote foi preservado.

Para reproduzir nesta máquina, use /workspace/toolchains/build-switchphone.sh assembleRelease lintRelease e o script de assinatura com caminhos para a chave e arquivo de senha privados. A chave de distribuição deve ser preservada em backup seguro para futuras atualizações; não enviar para GitHub ou chat.
