# Validação 0.2.5 experimental

- assembleRelease e lintRelease: BUILD SUCCESSFUL, 0 erros e 1 aviso conhecido de orientação paisagem fixa.
- APK release não depurável: versionCode 7, versionName 0.2.5-experimental, minSdk 28, compile/target 35. Assinatura v3 e zipalign conferidos.
- Certificado SHA-256 c706c29aba14d93b44452100f90c36584fafc1efb85bde4ff959ed1183b8e74a, igual às versões 0.2.1–0.2.4; instalável como atualização.
- APK: 115447 bytes; SHA-256 93f1860d288736f1804b528c26cc7ccf5ebc057157b85825c03c41d870840ded.
- Permissões mantidas: Bluetooth CONNECT/ADVERTISE, vibração e serviço foreground connectedDevice; sem Internet, contatos, chamadas, localização ou varredura.
- 2.486 asserções JVM aprovadas: ControllerState 28, NintendoProtocol 2.157 (incluindo 5.000 pacotes malformados/aleatórios), PairingFlow 126, InputRouter 106, PairingPulse 8, BondMonitor 39, BondFailure 22.

## Correção visual

O teste Windows com destino Nintendo abriu o canal HID, mas a UI 0.2.4 mantinha pontos vermelhos em NEGOTIATING. A 0.2.5 usa a capacidade de envio pelo canal real para verde fixo/Conectado; não altera fase, protocolo ou timeout. A mensagem de negociação pendente permanece amarela e o diagnóstico explicita Modo Nintendo negociado. Sem canal, controles continuam cinzas; erro/desconexão retira o verde. Acessibilidade descreve Canal HID conectado. Textos de compatibilidade registram o teste genérico Windows recebido.

Não executados neste ambiente: interface em telefone/emulador, rádio, Windows/USB, jogo ou instalação física da 0.2.5. O usuário realiza essas validações. Build/contratos não demonstram correção do pareamento Switch.

## Evidência física recebida: APK 0.2.4

Telefone Xiaomi 2511FPC34G/Android 16 API 36; Switch Lite 21.1.0|AMS 1.10.1|E, CNX.

1. Destino PC: SwitchPhone Gamepad, status OK no joy.cpl, usuário confirmou entradas. Sem versão/build Windows, inventário completo, jogo ou medição de latência.
2. Destino Nintendo no mesmo Windows: Pro Controller; registro aos 1 s, callback HID CONNECTED/2 e enlace aos 49 s; sete envios aceitos pelo Android, L+R aos 57 s. Nenhum GET/SET/Interrupt; NEGOTIATING. Vínculo UNKNOWN é esperado pelo filtro Nintendo Switch quando o host real é PC. Não confirma negociação/consumo Nintendo.
3. Switch, teste limpo: nenhum vínculo salvo, registro aos 1 s, BONDING aos 38 s, NONE aos 46 s, sem BONDED, canal HID ou pedidos do host; motivo Android 0 sem causa detalhada. Também falhou sem connect automático nas 0.2.3/0.2.4. Ordem de preparação controlada não resolveu.

## MissionControl conferido

exefs.nsp recebido: 166310 bytes, SHA-256 4a21c9d7333d6f7944f88c2067d49c7fb5a7506e0f83fe5898c7d9abb9ce48fa, byte a byte oficial v0.14.2. ZIP recebido: 30 bluetooth_patches e 29 btm_patches, todos idênticos ao mesmo pacote oficial, sem ausências/diferenças. Apenas lidos, não executados ou redistribuídos. Usuário confirmou MissionControl On em Background services após reiniciar, antes de alterar botões. Aplicação dos patches em memória não inspecionada.

HOS 21.1.0/AMS 1.10.1 não motivam atualizar o console: o requisito >=1.10.2 da v0.14.2 é específico de HOS 21.2.0+.

## Coletor nativo separado

BondStateMachine do Android 16 registra status/hciReason, mas o broadcast do app não encaminha hciReason. scripts/windows lê por ADB apenas o processo Bluetooth, desde o horário atual, e exporta tempo relativo e três códigos. Não lê chaves, limpa logs ou remove vínculos; não inclui raw log/MAC/serial no JSON. Ausência de eventos não é diagnóstico da causa. Não exige novas permissões no app.

Cinco testes automatizados aprovados com PowerShell 7.6.7/Linux e ADB simulado: evento terminal; descarte de dados privados em stdout/stderr/JSON; erros USB/PID/horário/logcat; prazo sem eventos; limite de 64 eventos; parser rejeita linhas inválidas. Não são teste de driver Windows, PowerShell 5.1 real ou rádio Xiaomi.

Platform-Tools Windows 37.0.1 obtido de dl.google.com; tamanho/SHA-1 conferidos contra manifesto oficial HTTPS; SHA-256 fixado no coletor e três binários executáveis. Não redistribuídos no ZIP. PowerShell Linux v7.6.7 obtido da release oficial com SHA-256 conferido contra hashes.sha256 oficial. TLS/checksums não desativados.

Chave/senha de assinatura fora do repositório e ZIP. Build atual: /workspace/toolchains/build-switchphone.sh assembleRelease lintRelease; assinatura por scripts/sign-release.sh com caminhos privados. Fontes em bluetooth-research.md.

Conferência adicional com PowerShell real no Linux: download HTTPS do pacote Google, hash do ZIP, extração e hashes dos três binários aprovados. Cache com DLL alterada foi recusado antes de qualquer execução. Nenhum executável Windows foi executado aqui.

Suporte posterior: usuário abriu CMD dentro do ZIP, sem PS1 disponível. Iniciador ganhou verificação de arquivo e instrução Extrair tudo; revisão de sintaxe manual, sem execução Windows neste ambiente. Após extrair, o coletor executou no Windows até o preflight USB e informou não autorizado/encontrado. Usuário confirmou MTP/transferência de arquivos, que não equivale a Depuração USB/ADB; orientado ativar Depuração USB e aceitar o computador. Coleta física ainda não recebida. APK permanece idêntico.

## Coletor USB 1.1.0 após captura vazia

Usuário enviou JSON v1 válido, duration_seconds=90, outcome=no_events, events=[]. O fluxo passou por get-state=device, consulta do processo Bluetooth e horário Android, sem erro do coletor; a autorização ADB funcionou nessa execução. Não há código de falha Bluetooth no arquivo. Usuário confirmou tentativa real durante a janela e aparecimento de Associer no celular.

Revisão encontrou erro no filtro do coletor: Utils.TAG_PREFIX_BLUETOOTH="Bluetooth" e BondStateMachine.TAG usa esse prefixo no código Android 16 consultado, enquanto o coletor selecionava só BondStateMachine. Não comprova qual tag a Xiaomi emite, mas a referência lida estava incorretamente coberta.

Regressão nova modela filtro de tags do logcat: falhou antes da correção (no_events) e passou após incluir BluetoothBondStateMachine:I e BondStateMachine:I, preservando PID/processo e descarte do conteúdo bruto. Seis testes aprovados com PowerShell 7.6.7/Linux e ADB simulado; APK não alterado, nenhum novo teste Android necessário. JSON inclui collector_version=1.1.0, lines_read e unmatched_lines; são contagens, sem texto das linhas. Execução dessa correção no Xiaomi ainda pendente.

Fonte adicional lida: https://github.com/GrapheneOS/platform_packages_modules_Bluetooth/blob/16/android/app/src/com/android/bluetooth/Utils.java , junto ao BondStateMachine da mesma árvore. Foram usados fatos do nome de tag para código original.
