# Validação 0.2.4 experimental

- assembleRelease e lintRelease: BUILD SUCCESSFUL. Lint: 0 erros, 1 aviso já conhecido de orientação paisagem fixa.
- APK release não depurável: versionCode 6, versionName 0.2.4-experimental, minSdk 28, target/compile 35. Assinatura v3 e zipalign conferidos.
- Certificado SHA-256 c706c29aba14d93b44452100f90c36584fafc1efb85bde4ff959ed1183b8e74a, igual às versões 0.2.1–0.2.3; instalável como atualização.
- APK: 115447 bytes; SHA-256 0441bda363a528aa12c5ff651045c37c1437f523971a3f72769357c4305c4472.
- Sem mudanças de permissões: Bluetooth CONNECT/ADVERTISE, vibração e serviço foreground connectedDevice. Sem Internet, contatos, chamadas, localização ou varredura.
- Testes JVM aprovados: 28 estado/descritor; 2.157 protocolo Nintendo (incluindo 5.000 pacotes malformados/aleatórios); 126 PairingFlow; 106 isolamento de toque local; 8 pulso L+R; 39 BondMonitor; 22 BondFailure. Total: 2.486 asserções.
- Novas regressões: snapshot de vínculo salvo não vira callback BONDED; perda terminal preserva origem/motivo; callbacks tardios não alteram marcos; KEY_MISSING é somente observação e não muda política nem abre canal; motivo ausente/desconhecido permanece explícito; código 9 não recebe atribuição inventada.

## Evidência física que motivou a mudança

Usuário: Xiaomi 2511FPC34G/Android 16 API 36, Switch Lite 21.1.0|AMS 1.10.1|E, pacote CNX. Captura do SD mostra arquivos em atmosphere/contents/010000000000bd00; usuário confirmou boot2 em flags. Isso não comprova execução nem correspondência dos patches. A versão MissionControl instalada ainda não foi identificada.

Log 0.2.3: registro HID em 1 s, Switch já vinculado, perda BONDED → NONE (12 → 10) em 7 s. Nenhuma solicitação connect do aplicativo, callback de conexão HID, pedido GET/SET/Interrupt ou envio de entrada. Portanto a retirada de connect imediato não resolveu essa ocorrência. O código antigo também apresentava a consulta de um vínculo salvo como confirmação nesta tentativa; a 0.2.4 separa esses fatos.

A 0.2.4 mantém o protocolo e a política de conexão da 0.2.3. Acrescenta diagnóstico opcional do motivo de perda Android e KEY_MISSING no Android 16+; sem APIs ocultas, reflexão, remoção automática de vínculos ou leitura de chaves. Motivo interno pode não ser disponibilizado pelo fabricante. Não receber KEY_MISSING não descarta falha de chave. Android também usa REMOVED/9 como fallback, portanto esse código não identifica culpado/causa sozinho.

Orientado teste físico com vínculo limpo: encerrar app, esquecer somente Nintendo Switch no Bluetooth do celular, Mudar ordem/modo de segurar no console, Parear/Associer. Solicitada conferência read-only de atmosphere/exefs_patches/bluetooth_patches e btm_patches com .ips. Não orientado apagar o banco global de controles, remover outros aparelhos, instalar patches de HOS antigo ou atualizar todo o console.

Fontes consultadas estão em bluetooth-research.md: notas CNX/MissionControl e código Android 16 mantido pelo GrapheneOS. Android Googlesource retornou 403; nenhuma alegação de leitura dessa página. Fatos de constantes/formato foram usados em código próprio.

Não executados diretamente no ambiente: teste instrumentado Android, rádio real ou entrada em jogo. O usuário posteriormente testou 0.2.4 no Windows e no Switch, conforme adendo abaixo; KEY_MISSING não foi observado e sua recepção real não está comprovada. Código/compilação/assinatura aprovados não demonstram correção da conexão física. Emulação continua parcial, sem IMU ativo, NFC, rumble do jogo ou pareamento manual com chaves.

Chave e senha privadas permanecem fora do repositório e ZIP. Build na máquina atual: /workspace/toolchains/build-switchphone.sh assembleRelease lintRelease; assinatura por scripts/sign-release.sh com caminhos privados. Assinatura própria não garante retirada de aviso do Play Protect.

## Adendo físico após a publicação

Em 2026-10-14, o usuário confirmou que o modo PC respondeu corretamente no Windows. A captura mostra Controladores de Jogo/joy.cpl com SwitchPhone Gamepad, status OK, e a página de teste com eixos/botões. Trata-se de resultado manual relatado, sem versão/build do Windows nem inventário de controles testados individualmente. Não equivale a teste em jogo, estabilidade, latência, NFC, IMU ou XInput.

Teste Nintendo 0.2.4 com a ordem de preparação controlada: nenhum vínculo salvo ao registrar HID em 1 s; BONDING 10 → 11 aos 38 s; NONE 11 → 10 aos 46 s. Sem callback BONDED, enlace HID, GET/SET/Interrupt ou envio de entradas. Motivo interno Android 0 não indica causa específica. O PC funcional demonstra o transporte HID genérico nesse telefone/host; não resolve nem prova culpa do MissionControl.

Próxima conferência: identificar o exefs.nsp do MissionControl instalado e comparar os arquivos/versões oficiais compatíveis com HOS 21.1.0/AMS 1.10.1. Presença de flags/boot2 e pastas de patches foi relatada; hashes e execução do módulo não foram verificados.

## Identificação do módulo enviado
O exefs.nsp enviado pelo usuário corresponde byte a byte ao módulo da release oficial MissionControl v0.14.2: 166310 bytes, SHA-256 4a21c9d7333d6f7944f88c2067d49c7fb5a7506e0f83fe5898c7d9abb9ce48fa. Foi apenas lido/comparado, não executado nem redistribuído. README v0.14.2 exige AMS >=1.10.2 especificamente no HOS 21.2.0+; o usuário informou HOS 21.1.0/AMS 1.10.1. Identificar o módulo não comprova sua execução nem o conteúdo dos patches no console. Referências dos arquivos bluetooth_patches e btm_patches foram preparadas para a próxima conferência.
