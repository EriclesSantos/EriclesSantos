# Validação 0.2.2 experimental

- assembleRelease e lintRelease: sucesso. Lint: 0 erros, 1 aviso de paisagem fixa mantida por requisito.
- APK release não depurável: versionCode 4, minSdk 28. Assinatura/alinhamento verificados pelo script de distribuição.
- Mesmo certificado da 0.2.1: SHA-256 c706c29aba14d93b44452100f90c36584fafc1efb85bde4ff959ed1183b8e74a. Atualização sobre 0.2.1 não exige desinstalar.
- APK: 103159 bytes. SHA-256 1b0b0e57054d0a8a316dfddbec6e2403cd187d5fd1c164ad440065be89add0bd.
- Manifesto: Bluetooth e vibração mais permissões normais FOREGROUND_SERVICE/CONNECTED_DEVICE. Sem Internet, contatos, histórico de chamadas, localização ou varredura Bluetooth.
- Testes JVM: 28 asserções de estado/descritor, 2.157 Nintendo (incluindo tratamento de 5.000 pacotes malformados/aleatórios), 126 de fluxo de pareamento, 106 de isolamento do teste local e 8 do pulso L+R. Total: 2.425 asserções aprovadas.
- Regressões cobertas: uma solicitação por etapa; não registrar HID antes da visibilidade/retorno ao foreground; foco/callbacks repetidos não reabrem diálogos; cancelamento/timeout invalidam callbacks tardios; teste local nunca altera relatórios Bluetooth periódicos; pulso L+R correto em 3F/30 libera preservando dedos mantidos.

Relato físico do usuário na 0.2.1: instalação concluída, MissionControl ativo, Switch Lite e diálogo Android de vínculo com Nintendo Switch sobre a tela LAYOUTS. Entradas/jogo não confirmados. Isso esclarece que houve tentativa de vínculo, mas não permite afirmar conexão HID/negociação Nintendo completas. A tela Layouts era prévia sem toque e o fluxo antigo interrompia o perfil durante a confirmação do sistema.

A 0.2.2 altera o preflight e mantém a importância do processo com serviço foreground durante a tentativa. Após vínculo com um único Nintendo Switch conhecido, faz uma conexão HID limitada a uma tentativa, sem varredura/extração de MAC/chaves; timeout encerra. Em múltiplos consoles, a escolha é explícita em Reconectar. Abertura da tela de controle e envio pré-negociação permitem confirmar L+R após enlace real. Pontos verdes continuam exigindo callbacks reais e modo Nintendo negociado.

Não foram executados testes instrumentados Android, emulador, serviço/diálogos num telefone real, pareamento físico 0.2.2 nem entrada em jogo. Essas mudanças precisam de novo teste do usuário. Modelo/Android e versões Atmosphère/MissionControl não foram informados; o diagnóstico copiável agora inclui dados básicos do telefone e etapas sem MAC, nome pessoal ou credenciais. Emulação permanece parcial, sem IMU ativo, NFC, rumble ou pareamento manual por LTK.

Chave e senha de assinatura permanecem fora do repositório/ZIP. Para repetir o build na máquina atual: /workspace/toolchains/build-switchphone.sh assembleRelease lintRelease; em seguida scripts/sign-release.sh com os caminhos privados. A assinatura não garante remoção do aviso do Play Protect.
