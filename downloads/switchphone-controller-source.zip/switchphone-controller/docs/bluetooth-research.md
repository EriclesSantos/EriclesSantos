# Sprint 0 — investigação técnica, atualizada para 0.2.0

Consulta em 2026-10-14. Fontes efetivamente obtidas e lidas por HTTPS:

- MissionControl, https://github.com/ndeadly/MissionControl — `71bbe2d4e97d618775b5a3e2f91bfeaf52d8b75e`: README e implementação de identificação/encaminhamento de controles.
- JoyCon Droid, https://github.com/TeamJCD/JoyConDroid — `e3074f867847ca083d1438f0d7368d41e1fba28a`: README, serviço HID e handlers de relatórios/subcomandos.
- Nintendo Switch Reverse Engineering, https://github.com/dekuNukem/Nintendo_Switch_Reverse_Engineering — `b354f21ae81f7b0d1d060b2b61e66ad0d9bc1756`: notas de Bluetooth, subcomandos e SPI.

A referência oficial pretendida https://developer.android.com/reference/android/bluetooth/BluetoothHidDevice retornou HTTP 403 neste ambiente. As assinaturas usadas foram verificadas por compilação contra SDK 35; não se alega ter lido essa página. Consulta adicional ao driver Linux retornou HTTP 429 e não integra as evidências técnicas lidas.

## Evidências de viabilidade
O README do MissionControl declara permitir JoyConDroid sem root. A função Identify de controller_management.cpp examina VID/PID e nomes oficiais Nintendo e escolhe famílias específicas; um gamepad HID genérico não é automaticamente reconhecido como controle compatível.

O README do JoyCon Droid apresenta ROOT REQUIRED para seu uso geral. O serviço inspecionado usa BluetoothHidDeviceAppSdpSettings/registerApp e delega GET/SET_REPORT a uma camada de controle. Os handlers evidenciam a necessidade de negociação e respostas próprias. O aviso de root e a declaração do MissionControl devem ser avaliados em conjunto, sem inferir compatibilidade universal.

A API HID Device existe desde Android API 28 e depende da implementação do fabricante. O código usa Bluetooth clássico HID; não é BLE HID/GATT. A API pública não permite impor MAC/VID/PID arbitrários nem acessar chaves de enlace privadas. Nome Pro Controller e SDP próprio são pedidos permitidos, mas não provam que a identidade será aceita pelo console.

## Decisão implementada
Dois modos separados: HID genérico para PC, não XInput, e emulação parcial do protocolo Pro Controller para Switch/MissionControl. Três layouts visuais compartilham comandos internos; não representam três emulações de marcas.

O modo Nintendo implementa 3F/21/30, identificação virtual, negociação de modos, botões/eixos, leitura limitada de calibração virtual, LEDs de jogador e contadores. A calibração é gerada para os analógicos de tela. Não contém firmware, EEPROM nem dados extraídos de controle real. NFC, IMU ativo, rumble, modo 31 e pareamento manual por LTK são recusados explicitamente; certos hosts podem exigir esses recursos e falhar. Detalhes em nintendo-protocol.md.

## Licenças
MissionControl contém LICENSE GPL v2 e o arquivo de identificação declara versão 2. Incorporar seu código exigiria avaliar cabeçalhos, atribuição e obrigações de distribuição do código correspondente. Não foi incorporado código.

No checkout do JoyCon Droid não foi encontrada licença explícita na raiz nem no serviço inspecionado. Repositório público não concede automaticamente licença de reutilização. Nenhum trecho, descritor, firmware ou EEPROM foi copiado. Seria necessário obter licença antes de reutilizar código.

Das notas de engenharia reversa foram utilizados fatos de formato de protocolo para uma implementação original, sem copiar exemplos de código. O código próprio está sob MIT. O Gradle Wrapper preserva seus avisos Apache 2.0 separadamente.

## Gate físico e riscos restantes
É necessário testar perfil HID num Android real, pareamento, SDP/identidade, negociação, mapeamento de todos os comandos, analógicos, estabilidade e operação em jogo. O mapeamento 3F em particular permanece experimental; o caminho principal é 0x30. Se houver requisito de identidade/chave inacessível pela API pública sem root, a estratégia pode precisar ser revista.

Não há Android/rádio/console conectado nesta máquina. Não foram validados Galaxy A23 ou outros modelos, versões de HOS/Atmosphère/MissionControl, latência, autonomia ou multiplayer. O APK pode não ser reconhecido pelo Switch. O aceite do MVP exige os testes reais descritos em installation.md, sem depender apenas de pontos verdes na interface ou testes JVM.

## Relato físico e correção 0.2.2

O usuário confirmou instalação e execução no Android, MissionControl ativo e uso de Switch Lite. Relatou diálogo de pareamento repetido e controles estáticos. A captura mostra Associer à Nintendo Switch no Android sobre a tela LAYOUTS. Isso comprova uma tentativa de vínculo, não aceitação em jogo; modelo/versão Android e versões Atmosphère/MissionControl ainda não informados.

O código fechava HID/restaurava o nome ao abrir visibilidade e recriava a sessão no retorno. Também bloqueava entradas antes de concluir negociação e a página LAYOUTS era só prévia. A correção separa confirmações prévias do registro, abre a tela interativa e permite entradas após enlace para L+R.

Foi lida a documentação oficial embutida em android-stubs-src.jar do SDK Platform 35, BluetoothHidDevice.registerApp: registro é necessário e o app é desregistrado automaticamente ao deixar de estar foreground. A sessão agora usa foreground service connectedDevice durante pareamento/uso, sem requisição extra de acesso a contatos/chamadas/notificações/varredura e com encerramento finito. As confirmações Android são emitidas uma vez por tentativa; nome Pro Controller é observado antes da visibilidade.

Fonte complementar SDL (licença zlib) consultada em seu driver hidapi Switch para confirmar bits 3F de L/R. Não foi copiado código. Correções e contratos passam em JVM/build; a 0.2.2 ainda exige novo teste no aparelho/console do usuário.
