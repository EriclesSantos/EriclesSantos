# Instalação e primeiro teste

## Compilação
Abra `android-app` no Android Studio. Use JDK 17/21, SDK Platform 35 e Build Tools 35.0.0. Execute `./gradlew assembleDebug lintDebug` (no Windows: `gradlew.bat assembleDebug lintDebug`). O APK debug está em `app/build/outputs/apk/debug/app-debug.apk`.

Instale copiando o APK ao telefone e autorizando essa origem, ou use:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Esta é uma aplicação experimental assinada com chave debug. Não há publicação em Releases nem chave de produção incluída nos fontes.

## Pareamento em um botão
1. No início escolha **PC** ou **Switch experimental**. O layout visual pode ser qualquer um dos três.
2. Toque **Parear** no topo. Aceite dispositivos próximos (Android 12+) e ativação do Bluetooth, se solicitados. Não é solicitado acesso à localização.
3. Aguarde o registro HID e aceite a visibilidade de 120 segundos. Se a tela do sistema interromper a Activity, o app retoma o registro após sua resposta.
4. Inicie o pareamento pelo computador ou console. Deixe o aplicativo aberto. Os três pontos vermelhos pulsam enquanto aguarda.
5. No PC, pontos verdes indicam enlace HID confirmado. No Switch, também é necessário receber a negociação de modo Nintendo. Isso ainda não confirma funcionamento em jogo.
6. Abra Controle. Botões inativos permanecem cinzas e rebaixados, sem enviar toques. Após confirmação, botões e analógicos ficam disponíveis.
7. Use **Diagnóstico** para ver progresso, falhas e comandos não implementados. **Encerrar** libera entradas, fecha o perfil e tenta restaurar o nome Bluetooth anterior.

O modo Nintendo solicita temporariamente o nome Bluetooth `Pro Controller`. Se o processo cair, a recuperação do nome fica registrada e é tentada ao reabrir com permissão Bluetooth. A API de mudança de nome é assíncrona; o marcador só é removido depois que a restauração é observada.

## Computador
Use Bluetooth clássico com suporte a host HID. No Windows, `Win+R` → `joy.cpl` permite verificar botões e analógicos. Um jogo que exige XInput pode não aceitar diretamente o gamepad genérico. Outros sistemas dependem de seu suporte HID. Este projeto ainda não foi testado fisicamente em nenhum sistema.

Teste os 14 botões, A+B simultâneos, ombros+direcional+analógicos, diagonais, cancelamento de toque, todos os layouts e configurações. L3/R3 são botões separados. Desconecte o host, desligue Bluetooth, negue/revogue permissão e confira mensagens e bloqueio visual. Para reconectar, escolha explicitamente um host já pareado.

Relatório PC ID 1, sete bytes: máscara LE16, LX/LY/RX/RY assinados de 8 bits, hat (0=N, 1=NE, 2=Leste, 3=SE, 4=S, 5=SO, 6=Oeste, 7=NO, 8=neutro). Não confundir com o formato Nintendo.

## Switch real
1. Use Atmosphère e MissionControl compatíveis com seu firmware, seguindo as instruções desses projetos. Anote modelo do telefone, Android, modelo do console, HOS, Atmosphère e MissionControl.
2. Selecione Switch experimental no app e toque Parear. No console abra **Controles → Mudar ordem/modo de segurar**.
3. Verifique se surge um dispositivo/controle, se há conexão e qual é a última mensagem do diagnóstico. Os comandos de modo recebidos são registrados. Na seleção de jogadores, experimente L+R após os pontos ficarem verdes.
4. Em um jogo que aceite Pro Controller, confirme cada botão e os dois analógicos. No layout Nintendo, o botão inferior é B; outros layouts preservam posições, não os símbolos Nintendo.
5. Teste retorno ao app, reconexão e liberação de entradas ao desconectar. A sessão é encerrada em segundo plano por decisão de projeto.

A emulação é parcial e pode falhar na identificação, pareamento ou negociação. Chaves de pareamento manual, giroscópio, NFC, rumble e protocolos/modos não suportados são recusados explicitamente. Não há teste de quatro jogadores nem garantia para V1/V2/Lite/OLED.

Se falhar, guarde a mensagem de Diagnóstico e, por USB, `adb logcat -s SwitchPhone`. Não publique informações pessoais do telefone. Nenhum teste físico foi executado nesta máquina.
