# Instalação e teste 0.2.5

Baixe o APK release da pasta downloads no GitHub. A 0.2.5 usa a mesma assinatura da 0.2.1–0.2.4 e pode ser instalada como atualização, preservando preferências. A antiga 0.2.0 era debug e exige desinstalação por mudança de assinatura. Aviso de desenvolvedor desconhecido do Play Protect pode continuar; assinatura própria não equivale a revisão pelo Google.

## Switch Lite e demais modelos
1. No console, confirme Atmosphère/MissionControl compatíveis e deixe o console na tela inicial durante a preparação do celular. Procurar controles é para localizar controles já vinculados, não para adicionar um novo.
2. No início do app escolha o **destino Switch experimental**. Escolher só o layout Nintendo não muda o protocolo. Destino padrão de novas preferências é Switch; escolha PC explicitamente para computadores.
3. Toque **Parear**. A tela interativa abre automaticamente. Aceite dispositivos próximos e ativação do Bluetooth se solicitados, depois permita visibilidade por 120 s. Não há novo registro HID durante esses diálogos.
4. O app aguarda o retorno à tela com foco, inicia uma sessão em primeiro plano e registra HID. Três pontos vermelhos pulsam com prazo visível. Não há varredura de dispositivos pelo app. **Só após aparecer HID registrado/aguardando Switch, abra Controles → Mudar ordem/modo de segurar no console.** Essa ordem evita encontrar o celular antes do registro do perfil.
5. Se aparecer **Associer à Nintendo Switch ?**, toque **Associer**. Acesso a contatos/histórico de chamadas não é necessário; deixe a caixa desmarcada. O serviço mantém o perfil durante essa confirmação, evitando encerrá-lo/restaurar o nome repetidamente.
6. Após o vínculo Android, aguarde o canal HID do Switch. A 0.2.3 não chama reconexão automaticamente ao aceitar Associer, para evitar disputar a conexão de entrada. Se o vínculo permanecer aceito e nada acontecer, Abrir enlace HID permite uma tentativa manual após 5 s, usando um vínculo já aceito. Se houver vários consoles, escolha o host. Quando o enlace HID existir, os controles e **Confirmar L+R** são habilitados mesmo durante negociação Nintendo. Pressione esse botão ou L e R simultaneamente. O pulso dura 300 ms e libera sem cancelar dedos que continuam pressionados.
7. Pontos verdes indicam canal HID conectado. A mensagem informa separadamente negociação Nintendo pendente/concluída; aceitar o vínculo Android sozinho não fica verde. Verifique botões/analógicos em um jogo; entrada no Switch ainda não está validada. IMU/NFC/rumble e pareamento manual por chaves continuam não implementados.
8. Se expirar, use **Diagnóstico → Copiar** e envie o texto. Ele mostra versão do app, modelo/Android, destino, permissões, etapa, estado atual, marcos HID/enlace antes do encerramento, eventos de vínculo, callbacks e contagem de pedidos do host. Se o vínculo falhar ou for removido, a tentativa encerra imediatamente e não reinicia por eventos tardios do sistema. Não contém MAC, chaves ou nome pessoal do telefone. Uma nova tentativa exige tocar Parear.

**Layouts é uma prévia sem toque.** Use Selecionar ou Parear para abrir o controle. Sem enlace, controles reais permanecem cinza; não ficarão verdes apenas porque o diálogo de vínculo foi aceito.

## Teste local de botões
Use **Testar toque** no início ou controle. O banner amarelo informa TESTE LOCAL. Confira multitoque, L/R, gatilhos, analógicos e direcional. Esse modo tem estado independente e não transmite comandos nem muda pontos de conexão para verde. Encerre-o para parear; abrir uma conexão real também o encerra. L3/R3 são botões separados.

## Computador
Escolha destino PC, siga Parear e faça o vínculo pelo computador. No Windows use Win+R → joy.cpl. É HID genérico, não XInput. Jogos podem exigir mapeamento. No Xiaomi 2511FPC34G/Android 16 com o app 0.2.4, o usuário confirmou reconhecimento e resposta às entradas no joy.cpl do Windows. Versão/build do Windows, todos os controles individualmente e jogos permanecem sem inventário/validação.

## Build
Abra android-app no Android Studio, use JDK 17/21, SDK Platform 35 e Build Tools 35.0.0. Execute ./gradlew assembleRelease lintRelease (Windows: gradlew.bat). Assine pelo Android Studio com sua chave ou scripts/sign-release.sh com caminhos privados. Não publique chave/senha. ./tests/run.sh executa contratos JVM, incluindo regressões de pareamento e isolamento do teste local.

O app não pede Internet, localização, varredura Bluetooth, contatos ou chamadas. As permissões normais de foreground service/connected device sustentam somente a sessão ativa ou tentativa com prazo. Encerrar/cancelar, timeout, erro e saída da tela ativa encerram o serviço e liberam entradas. Para capturar o código Bluetooth nativo omitido pelo broadcast do app, use o [coletor USB do Windows](../scripts/windows/LEIA-ME.txt). Não é preciso compartilhar um bugreport ou log HCI completo.

## Conferir versões do console
Em Configurações do console → Console, consulte Versão atual perto de Atualização do console. Leia a linha inteira, incluindo o trecho AMS do Atmosphère; não é necessário iniciar atualização. MissionControl não tem interface própria: procure o nome do ZIP instalado ou a versão do pacote no instalador utilizado. A pasta atmosphere/contents/010000000000bd00 indica arquivos presentes, mas sua presença sozinha não comprova versão nem que o módulo está ativo. Não apague todos os vínculos do console para obter essas informações.

## Vínculo antigo removido antes do HID
1. Encerre a sessão no app. No celular, Configurações → Bluetooth → Nintendo Switch → Esquecer/Desparear. Remova apenas esse vínculo; preserve outros aparelhos e os controles do console.
2. Deixe o Switch na tela inicial. No app use Parear; aguarde HID registrado. Só então abra Mudar ordem/modo de segurar no Switch e aceite Associer sem acesso a contatos no Android. Esse teste deve partir sem Nintendo Switch salvo no celular.
3. Se cair novamente, copie o diagnóstico 0.2.4: vínculo salvo encontrado e callback BONDED agora são campos distintos. O motivo de remoção pode ser disponibilizado pelo Android; código 9 é genérico em alguns caminhos e não prova ação do usuário/console. KEY_MISSING pode sinalizar falta de chave no Android 16+, mas sua ausência não descarta falha de autenticação.
4. Confira no SD as pastas atmosphere/exefs_patches/bluetooth_patches e btm_patches, com arquivos .ips. A distribuição MissionControl também contém hid_patches. A pasta do módulo e flags/boot2.flag não bastam para verificar carregamento/correspondência dos patches ao HOS. Não copie patches de outra versão de firmware.

CNX: notas do pacote incluem MissionControl e registram que passou a vir desativado por padrão, habilitável por Ultrahand/Hekate Toolbox. Neste caso, os arquivos recebidos correspondem ao MissionControl v0.14.2 oficial e o usuário confirmou MissionControl On ao abrir Background services após reiniciar, antes de alterar botões. Aplicação de patches em memória não foi inspecionada. Reiniciar no Atmosphère carrega os módulos habilitados; suspender não basta.
