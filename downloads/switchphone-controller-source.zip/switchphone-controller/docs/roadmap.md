# Roadmap

- Sprint 0: pesquisa, licenças, riscos e plano físico documentados.
- Sprint 1: API HID, diagnóstico e emulação parcial Nintendo implementados. Validação física e eventuais comandos adicionais ainda pendentes.
- Sprint 2: controles completos, analógicos, multitoque e vibração local implementados; validação física pendente.
- Sprint 3: três layouts e preferências implementados; revisão no telefone pendente.
- Sprint 4: callbacks, timeouts e limpeza implementados; consumo, latência e desempenho ainda não medidos.
- Sprint 5: build e CI preparados. Release assinada de produção e publicação aguardam testes físicos.

IMU, NFC, rumble do jogo, acessibilidade avançada e multiplayer não estão prontos. Não há garantia de compatibilidade universal sem root. Esta versão não atende aos critérios físicos de aceite do MVP antes dos testes reais.
