package com.switchphone.layouts;

import android.content.Context;
import android.graphics.*;
import android.util.SparseArray;
import android.view.*;
import com.switchphone.controller.ControllerState;
import com.switchphone.settings.Preferences;
import com.switchphone.haptics.Haptics;
import java.util.ArrayList;

/** Vector controls with independent pointer ownership and no render/update loop. */
public final class ControllerView extends View {
    public static final String[] NAMES={"Nintendo Switch","Xbox","PlayStation"};
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Key> keys=new ArrayList<>();
    private final SparseArray<Touch> touches=new SparseArray<>();
    private final ControllerState state;
    private final Preferences prefs;
    private final Runnable changed;
    private final int layout;
    private final boolean preview;
    private boolean inputAvailable;
    private float lx,ly,rx,ry,radius,unit;
    private float leftX,leftY,rightX,rightY;
    private int held,hat=8;
    private final int accent=Color.rgb(77,220,197);
    private static final class Key {
        final float x,y,w,h; final String label; final int id; final boolean round;
        Key(float x,float y,float w,float h,String label,int id,boolean round) {
            this.x=x;this.y=y;this.w=w;this.h=h;this.label=label;this.id=id;this.round=round;
        }
        boolean contains(float px,float py) {
            if (round) return Math.hypot(px-x,py-y)<=w/2;
            return Math.abs(px-x)<=w/2 && Math.abs(py-y)<=h/2;
        }
    }
    private static final class Touch {
        int stick; float x,y;
        Touch(int stick,float x,float y) { this.stick=stick;this.x=x;this.y=y; }
    }
    public ControllerView(Context context,int layout,ControllerState state,Preferences prefs,Runnable changed,boolean preview) {
        super(context);this.layout=layout;this.state=state;this.prefs=prefs;this.changed=changed;this.preview=preview;this.inputAvailable=preview;
        setContentDescription(NAMES[layout]+" controle virtual multitoque");
        setFocusable(true);
        if (!preview) setKeepScreenOn(true);
    }
    public ControllerView(Context context) { this(context,0,new ControllerState(),new Preferences(context),()->{},true); }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) {
        if(!preview)release();
        keys.clear(); unit=Math.min(w/900f,h/370f); radius=48*unit;
        leftX=w*(layout==2?.36f:.20f);leftY=h*(layout==2?.72f:.38f);
        rightX=w*(layout==2?.64f:.69f);rightY=h*.73f;
        float dx=w*.17f,dy=h*(layout==2?.39f:.75f),d=30*unit;
        key(dx,dy-d,d,d,"▲",20,false); key(dx+d,dy,d,d,"▶",21,false);
        key(dx,dy+d,d,d,"▼",22,false); key(dx-d,dy,d,d,"◀",23,false);
        float fx=w*.84f,fy=h*.41f,fr=35*unit,fw=49*unit;
        String[] labels=layout==0?new String[]{"B","A","Y","X"}:layout==1?new String[]{"A","B","X","Y"}:new String[]{"×","○","□","△"};
        key(fx,fy+fr,fw,fw,labels[0],0,true);key(fx+fr,fy,fw,fw,labels[1],1,true);
        key(fx-fr,fy,fw,fw,labels[2],2,true);key(fx,fy-fr,fw,fw,labels[3],3,true);
        String[] shoulders=layout==0?new String[]{"L","R","ZL","ZR"}:layout==1?new String[]{"LB","RB","LT","RT"}:new String[]{"L1","R1","L2","R2"};
        key(w*.15f,h*.10f,86*unit,34*unit,shoulders[0],4,false);
        key(w*.85f,h*.10f,86*unit,34*unit,shoulders[1],5,false);
        key(w*.29f,h*.10f,86*unit,34*unit,shoulders[2],6,false);
        key(w*.71f,h*.10f,86*unit,34*unit,shoulders[3],7,false);
        String minus=layout==0?"−":layout==1?"View":"Share";
        String plus=layout==0?"+":layout==1?"Menu":"Options";
        key(w*.43f,h*.32f,68*unit,33*unit,minus,8,false);
        key(w*.57f,h*.32f,68*unit,33*unit,plus,9,false);
        key(w*.45f,h*.52f,60*unit,30*unit,"Home",10,false);
        key(w*.55f,h*.52f,60*unit,30*unit,"Capture",11,false);
        key(w*.40f,h*.92f,58*unit,28*unit,"L3",12,false);
        key(w*.60f,h*.92f,58*unit,28*unit,"R3",13,false);
    }
    private void key(float x,float y,float w,float h,String label,int id,boolean round) { keys.add(new Key(x,y,w,h,label,id,round)); }
    private void text(Canvas c,String s,float x,float y,float size,int color) {
        paint.setColor(color);paint.setTextSize(size);paint.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y-(paint.ascent()+paint.descent())/2,paint);
    }
    @Override protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.rgb(13,20,29));
        paint.setColor(Color.rgb(20,31,43));canvas.drawRoundRect(8*unit,4*unit,getWidth()-8*unit,getHeight()-4*unit,40*unit,40*unit,paint);
        text(canvas,NAMES[layout].toUpperCase(java.util.Locale.ROOT),getWidth()/2f,getHeight()*.10f,13*unit,accent);
        for (Key k:keys) {
            boolean down=k.id<14?(held&(1<<k.id))!=0:dpadDown(k.id);
            if (!inputAvailable) {
                paint.setColor(Color.rgb(8,12,17));
                if(k.round) canvas.drawCircle(k.x,k.y,k.w/2+2*unit,paint);
                else canvas.drawRoundRect(k.x-k.w/2-2*unit,k.y-k.h/2-2*unit,k.x+k.w/2+2*unit,k.y+k.h/2+2*unit,10*unit,10*unit,paint);
            }
            paint.setColor(!inputAvailable?Color.rgb(35,40,47):down?accent:Color.rgb(42,57,72));
            canvas.save();if(!inputAvailable||down)canvas.translate(0,2*unit);
            if (k.round) canvas.drawCircle(k.x,k.y,k.w/2,paint);
            else canvas.drawRoundRect(k.x-k.w/2,k.y-k.h/2,k.x+k.w/2,k.y+k.h/2,9*unit,9*unit,paint);
            text(canvas,k.label,k.x,k.y,(k.round?21:12)*unit,!inputAvailable?Color.rgb(102,111,121):down?Color.rgb(10,27,30):Color.rgb(233,241,247));
            canvas.restore();
        }
        stick(canvas,leftX,leftY,lx,ly,"L");stick(canvas,rightX,rightY,rx,ry,"R");
        if(!inputAvailable)text(canvas,"CONTROLES INATIVOS • PAREIE O DISPOSITIVO",getWidth()/2f,getHeight()*.98f,10*unit,Color.rgb(137,145,155));
    }
    private boolean dpadDown(int id) {
        return hat!=8 && (id==20&&(hat==7||hat==0||hat==1) || id==21&&(hat>=1&&hat<=3) || id==22&&(hat>=3&&hat<=5) || id==23&&(hat>=5&&hat<=7));
    }
    private void stick(Canvas c,float x,float y,float ax,float ay,String label) {
        paint.setColor(Color.rgb(12,20,29));c.drawCircle(x,y,radius,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2*unit);paint.setColor(Color.rgb(72,94,111));c.drawCircle(x,y,radius,paint);paint.setStyle(Paint.Style.FILL);
        paint.setColor(!inputAvailable?Color.rgb(36,41,48):(ax!=0||ay!=0)?accent:Color.rgb(64,84,104));c.drawCircle(x+ax*radius*.48f,y+ay*radius*.48f,radius*.53f,paint);
        text(c,label,x+ax*radius*.48f,y+ay*radius*.48f,15*unit,inputAvailable?Color.WHITE:Color.rgb(100,110,120));
    }
    private int stickAt(float x,float y) {
        if (Math.hypot(x-leftX,y-leftY)<radius*1.1f) return 1;
        if (Math.hypot(x-rightX,y-rightY)<radius*1.1f) return 2;
        return 0;
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (preview) return false;
        if (!inputAvailable) return true;
        getParent().requestDisallowInterceptTouchEvent(true);
        int action=event.getActionMasked(),index=event.getActionIndex();
        if (action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
            int stick=stickAt(event.getX(index),event.getY(index));
            for (int i=0;i<touches.size();i++) if (stick!=0 && touches.valueAt(i).stick==stick) stick=-1;
            touches.put(event.getPointerId(index),new Touch(stick,event.getX(index),event.getY(index)));
            Haptics.press(getContext(),prefs.vibration());
        }
        for (int i=0;i<event.getPointerCount();i++) {
            Touch t=touches.get(event.getPointerId(i)); if (t!=null) {t.x=event.getX(i);t.y=event.getY(i);}
        }
        if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP) {
            touches.remove(event.getPointerId(index)); if (action==MotionEvent.ACTION_UP) performClick();
        }
        if (action==MotionEvent.ACTION_CANCEL) touches.clear();
        update();return true;
    }
    private void update() {
        held=0;lx=ly=rx=ry=0;boolean up=false,down=false,left=false,right=false;
        for (int i=0;i<touches.size();i++) {
            Touch t=touches.valueAt(i);
            if (t.stick>0) {
                float cx=t.stick==1?leftX:rightX,cy=t.stick==1?leftY:rightY;
                float x=(t.x-cx)/radius,y=(t.y-cy)/radius;
                float length=(float)Math.hypot(x,y); if(length>1) {x/=length;y/=length;}
                x=ControllerState.filterAxis(x,prefs.deadZone()/100f,prefs.sensitivity()/100f);
                y=ControllerState.filterAxis(y,prefs.deadZone()/100f,prefs.sensitivity()/100f);
                if (t.stick==1) {lx=x;ly=y;} else {rx=x;ry=y;}
            } else if (t.stick==0) {
                // D-pad diagonals are reachable within its square footprint.
                float dx=getWidth()*.17f,dy=getHeight()*(layout==2?.39f:.75f),d=30*unit;
                if (Math.abs(t.x-dx)<=d*1.55f && Math.abs(t.y-dy)<=d*1.55f) {
                    up|=t.y<dy-d*.40f;down|=t.y>dy+d*.40f;
                    left|=t.x<dx-d*.40f;right|=t.x>dx+d*.40f;
                }
                for (Key k:keys) if (k.id<14 && k.contains(t.x,t.y)) held|=1<<k.id;
            }
        }
        int horizontal=(right?1:0)-(left?1:0),vertical=(down?1:0)-(up?1:0);
        hat=vertical<0?(horizontal<0?7:horizontal>0?1:0):vertical>0?(horizontal<0?5:horizontal>0?3:4):horizontal<0?6:horizontal>0?2:8;
        state.replace(held,hat,lx,ly,rx,ry);changed.run();invalidate();
    }
    public void setInputAvailable(boolean available) { if(inputAvailable==available)return;inputAvailable=available;if(!available)release();invalidate(); }
    public void release() { touches.clear();update(); }
    @Override public boolean performClick() { super.performClick();return true; }
    @Override protected void onDetachedFromWindow() { if (!preview) release();super.onDetachedFromWindow(); }
}
