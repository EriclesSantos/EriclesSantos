package com.switchphone.bluetooth;

/** A Bluetooth bond is not a HID connection. Never initiates a connection or retries a lost bond. */
public final class BondMonitor {
    public enum State { UNKNOWN, BONDING, BONDED, LOST }
    public enum Change { IGNORED, BONDING, BONDED, FAILED, REMOVED }
    public static final long MANUAL_LINK_GRACE_MS=5000;
    private State state=State.UNKNOWN;
    private boolean everBonded,outboundRequested;
    private long bondedAt;
    public void reset(){state=State.UNKNOWN;everBonded=false;outboundRequested=false;bondedAt=0;}
    public State state(){return state;}
    public boolean everBonded(){return everBonded;}
    public boolean outboundRequested(){return outboundRequested;}
    public Change observe(State next,long now){
        if(state==State.LOST||state==next||next==State.UNKNOWN)return Change.IGNORED;
        if(next==State.LOST){
            if(state==State.UNKNOWN)return Change.IGNORED;
            state=State.LOST;return everBonded?Change.REMOVED:Change.FAILED;
        }
        state=next;
        if(next==State.BONDED){everBonded=true;bondedAt=now;return Change.BONDED;}
        return Change.BONDING;
    }
    public boolean canRequestLink(long now){return state==State.BONDED&&!outboundRequested&&now-bondedAt>=MANUAL_LINK_GRACE_MS;}
    /** Explicit user action only, after the host has had time to initiate its own HID channel. */
    public boolean requestLink(long now){if(!canRequestLink(now))return false;outboundRequested=true;return true;}
}
