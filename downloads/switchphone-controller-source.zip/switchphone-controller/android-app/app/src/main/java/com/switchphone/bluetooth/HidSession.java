package com.switchphone.bluetooth;

import android.bluetooth.*;
import android.content.Context;
import android.os.*;
import android.util.Log;
import com.switchphone.controller.ControllerState;
import com.switchphone.protocol.NintendoDescriptor;
import com.switchphone.protocol.NintendoProtocol;

/** Foreground-only HID transport. UI state follows callbacks, never a simulated connection. */
public final class HidSession implements AutoCloseable {
    public enum Phase { IDLE, REQUESTING, REGISTERING, READY, CONNECTING, NEGOTIATING, ACTIVE, ERROR, CLOSED }
    public interface Listener {
        void status(Phase phase,String message);
        void resetInput();
        void notice(String message);
    }
    private final Context context;
    private final Listener listener;
    private final ControllerState state;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final boolean nintendo;
    private final IdentityLease identity;
    private NintendoProtocol protocol;
    private BluetoothHidDevice hid;
    private BluetoothDevice host;
    private boolean requested,registered,closed,failing;
    private Phase phase=Phase.IDLE;
    private int generation;
    private long batteryChecked;
    private String lastNotice;
    public HidSession(Context context,ControllerState state,boolean nintendo,Listener listener){
        this.context=context;this.state=state;this.nintendo=nintendo;this.listener=listener;
        identity=new IdentityLease(context);
        BluetoothManager manager=context.getSystemService(BluetoothManager.class);
        adapter=manager==null?null:manager.getAdapter();
    }
    public Phase phase(){return phase;}
    public boolean registered(){return registered;}
    public boolean connected(){return host!=null;}
    public boolean inputReady(){return phase==Phase.ACTIVE;}
    private void phase(Phase next,String message){
        phase=next;generation++;Log.i("SwitchPhone",next+": "+message);listener.status(next,message);
    }
    private void notice(String message){if(message!=null&&!message.equals(lastNotice)){lastNotice=message;Log.i("SwitchPhone",message);listener.notice(message);}}
    private void timeout(long delay,String message){
        int expected=generation;main.postDelayed(()->{if(!closed&&generation==expected)fail(message);},delay);
    }
    private void fail(String message){
        if(closed||failing)return;failing=true;
        state.clear();main.removeCallbacks(tick);
        // Best effort neutral packet before disconnect; never leave a held game input intentionally.
        if(hid!=null&&host!=null){
            try{NintendoProtocol.Packet p=packet();hid.sendReport(host,p.id,p.data);hid.disconnect(host);}
            catch(SecurityException|IllegalStateException ignored){}
        }
        host=null;phase(Phase.ERROR,message);listener.resetInput();
        try{if(hid!=null&&registered){registered=false;hid.unregisterApp();}if(adapter!=null)identity.recover(adapter);}
        catch(SecurityException|IllegalStateException e){notice("Não foi possível confirmar a limpeza Bluetooth; use Encerrar e confira a permissão.");}
        failing=false;
    }
    public void start(){
        if(closed||requested)return;
        try{
            if(adapter==null){fail("Este dispositivo não oferece Bluetooth.");return;}
            if(!adapter.isEnabled()){fail("Bluetooth desligado. Ative-o e tente novamente.");return;}
            if(nintendo){identity.acquire(adapter);protocol=new NintendoProtocol(identity.virtualAddress());updateBattery();}
            else identity.recover(adapter);
            phase(Phase.REQUESTING,"Carregando perfil Bluetooth HID…");
            requested=adapter.getProfileProxy(context,service,BluetoothProfile.HID_DEVICE);
            if(!requested){fail("Perfil HID Device indisponível neste Android.");return;}
            timeout(8000,"O perfil HID não respondeu em 8 segundos. Encerre e tente novamente.");
        }catch(SecurityException|IllegalStateException e){fail("Falha ao preparar Bluetooth: "+e.getMessage());}
    }
    private final BluetoothProfile.ServiceListener service=new BluetoothProfile.ServiceListener(){
        @Override public void onServiceConnected(int profile,BluetoothProfile proxy){
            if(closed||phase==Phase.ERROR){adapter.closeProfileProxy(profile,proxy);return;}
            hid=(BluetoothHidDevice)proxy;
            try{
                phase(Phase.REGISTERING,"Registrando "+(nintendo?"Pro Controller experimental":"gamepad para PC")+"…");
                BluetoothHidDeviceAppSdpSettings sdp=new BluetoothHidDeviceAppSdpSettings(
                    nintendo?"Pro Controller":"SwitchPhone Gamepad",nintendo?"SwitchPhone experimental controller":"SwitchPhone generic gamepad",
                    "SwitchPhone",BluetoothHidDevice.SUBCLASS2_GAMEPAD,nintendo?NintendoDescriptor.bytes():DiagnosticDescriptor.bytes());
                if(!hid.registerApp(sdp,null,null,command->main.post(command),callback))fail("Android recusou o registro HID. Outro app pode estar usando o perfil.");
                else timeout(8000,"Registro HID sem confirmação. Encerre e tente novamente.");
            }catch(SecurityException|IllegalStateException|IllegalArgumentException e){fail("Registro HID falhou: "+e.getMessage());}
        }
        @Override public void onServiceDisconnected(int profile){
            hid=null;host=null;registered=false;requested=false;main.removeCallbacks(tick);
            if(!closed){state.clear();phase(Phase.ERROR,"Serviço HID perdido; controles bloqueados.");listener.resetInput();}
        }
    };
    private final BluetoothHidDevice.Callback callback=new BluetoothHidDevice.Callback(){
        @Override public void onAppStatusChanged(BluetoothDevice plugged,boolean value){
            if(closed)return;
            if(phase==Phase.ERROR){
                registered=false;
                if(value&&hid!=null)try{hid.unregisterApp();}catch(SecurityException|IllegalStateException e){notice("Registro tardio não pôde ser encerrado.");}
                return;
            }
            registered=value;
            if(value)phase(Phase.READY,"HID registrado. Torne visível e pareie pelo "+(nintendo?"Switch":"computador")+".");
            else fail("HID desregistrado pelo Android. Mantenha o aplicativo em primeiro plano.");
        }
        @Override public void onConnectionStateChanged(BluetoothDevice device,int value){
            if(closed||phase==Phase.ERROR)return;
            if(value==BluetoothProfile.STATE_CONNECTING){phase(Phase.CONNECTING,"Conectando ao host Bluetooth…");timeout(15000,"O host não confirmou a conexão em 15 segundos.");return;}
            if(value==BluetoothProfile.STATE_CONNECTED){
                host=device;state.clear();listener.resetInput();
                if(nintendo){
                    protocol=new NintendoProtocol(identity.virtualAddress());batteryChecked=0;updateBattery();
                    phase(Phase.NEGOTIATING,"Bluetooth conectado; aguardando negociação Nintendo…");
                    timeout(12000,"Bluetooth conectou, mas o host não negociou o modo Nintendo. Verifique MissionControl e o modo escolhido.");
                }else phase(Phase.ACTIVE,"PC conectado • relatórios HID habilitados. Valide no jogo.");
                emit(packet());
            }else if(value==BluetoothProfile.STATE_DISCONNECTED){
                host=null;main.removeCallbacks(tick);state.clear();
                if(!failing&&phase!=Phase.ERROR)phase(Phase.ERROR,"Host desconectado; botões liberados e bloqueados. Use Parear ou Reconectar.");
                listener.resetInput();
            }else if(value==BluetoothProfile.STATE_DISCONNECTING&&phase!=Phase.ERROR){
                phase(Phase.CONNECTING,"Encerrando enlace Bluetooth…");state.clear();listener.resetInput();timeout(8000,"Desconexão não foi confirmada pelo host.");
            }
        }
        @Override public void onGetReport(BluetoothDevice device,byte type,byte id,int size){
            if(closed||hid==null)return;
            try{
                byte[] payload=null;int reportId=id&255;
                if(type==BluetoothHidDevice.REPORT_TYPE_INPUT){
                    if(!nintendo&&reportId==1)payload=state.report();
                    else if(nintendo&&protocol!=null){
                        if(reportId==0x21)payload=protocol.lastReply();
                        else if(reportId==protocol.mode())payload=protocol.input(state.report(),SystemClock.uptimeMillis()).data;
                    }
                }else if(nintendo&&protocol!=null&&type==BluetoothHidDevice.REPORT_TYPE_FEATURE&&reportId==2)payload=protocol.lastReply();
                if(payload==null){hid.reportError(device,BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ);notice("GET_REPORT solicitado não é suportado.");}
                else{if(size>0&&size<payload.length)payload=java.util.Arrays.copyOf(payload,size);if(!hid.replyReport(device,type,id,payload))fail("Android recusou resposta GET_REPORT.");}
            }catch(SecurityException|IllegalStateException e){fail("GET_REPORT falhou: "+e.getClass().getSimpleName());}
        }
        @Override public void onSetReport(BluetoothDevice device,byte type,byte id,byte[] data){
            if(closed||hid==null)return;
            try{
                if(type==BluetoothHidDevice.REPORT_TYPE_OUTPUT&&nintendo&&protocol!=null){
                    if(output(id&255,data))hid.reportError(device,BluetoothHidDevice.ERROR_RSP_SUCCESS);
                    else hid.reportError(device,BluetoothHidDevice.ERROR_RSP_INVALID_PARAM);
                }else{hid.reportError(device,BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ);notice("SET_REPORT solicitado não é suportado.");}
            }catch(SecurityException|IllegalStateException e){fail("SET_REPORT falhou: "+e.getClass().getSimpleName());}
        }
        @Override public void onInterruptData(BluetoothDevice device,byte reportId,byte[] data){
            if(!closed&&phase!=Phase.ERROR)output(reportId&255,data);
        }
        @Override public void onVirtualCableUnplug(BluetoothDevice device){if(!closed)fail("Host removeu o pareamento HID. Faça o pareamento novamente.");}
    };
    private boolean output(int id,byte[] data){
        if(!nintendo||protocol==null){notice("Host enviou comando não suportado no modo PC.");return false;}
        NintendoProtocol.Reply reply=protocol.output(id,data,state.report(),SystemClock.uptimeMillis());
        if(reply.packet!=null&&!emit(reply.packet))return false;
        notice(reply.message);
        if(reply.accepted&&protocol.negotiated()&&host!=null){
            if(phase!=Phase.ACTIVE)phase(Phase.ACTIVE,"Modo Nintendo negociado • teste físico ainda necessário.");
            main.removeCallbacks(tick);if(protocol.mode()==0x30)main.post(tick);
        }
        return reply.packet!=null||id==0x10;
    }
    private NintendoProtocol.Packet packet(){
        return nintendo&&protocol!=null?protocol.input(state.report(),SystemClock.uptimeMillis()):new NintendoProtocol.Packet(1,state.report());
    }
    private boolean emit(NintendoProtocol.Packet packet){
        if(closed||failing||hid==null||host==null||!registered)return false;
        try{if(hid.sendReport(host,packet.id,packet.data))return true;fail("Falha ao enviar relatório Bluetooth; controles bloqueados.");}
        catch(SecurityException|IllegalStateException e){fail("Envio Bluetooth falhou: "+e.getClass().getSimpleName());}
        return false;
    }
    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(closed||phase!=Phase.ACTIVE||protocol==null||protocol.mode()!=0x30)return;
            updateBattery();if(emit(packet()))main.postDelayed(this,17);
        }
    };
    private void updateBattery(){
        if(protocol==null)return;long now=SystemClock.uptimeMillis();if(now-batteryChecked<1000)return;batteryChecked=now;
        BatteryManager manager=context.getSystemService(BatteryManager.class);
        if(manager!=null)protocol.battery(manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY),manager.isCharging());
    }
    public void reconnect(BluetoothDevice device){
        if(!registered||hid==null){notice("Registre HID antes de reconectar.");return;}
        if(host!=null){notice("Já existe um host conectado.");return;}
        try{phase(Phase.CONNECTING,"Solicitando reconexão…");if(!hid.connect(device))fail("Reconexão recusada pelo Android.");else timeout(15000,"O host não confirmou a reconexão.");}
        catch(SecurityException|IllegalStateException e){fail("Falha na reconexão: "+e.getClass().getSimpleName());}
    }
    public void send(){if(inputReady())emit(packet());}
    public void release(){state.clear();if(inputReady())emit(packet());}
    @Override public void close(){
        if(closed)return;release();closed=true;main.removeCallbacksAndMessages(null);state.clear();
        String cleanupError=null;
        try{
            if(hid!=null){if(host!=null)hid.disconnect(host);hid.unregisterApp();adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE,hid);}
        }catch(SecurityException|IllegalStateException e){cleanupError="Não foi possível confirmar o encerramento HID: "+e.getClass().getSimpleName();notice(cleanupError);}
        hid=null;host=null;registered=false;listener.resetInput();
        try{if(adapter!=null)identity.recover(adapter);}
        catch(SecurityException|IllegalStateException e){cleanupError="Nome Bluetooth não restaurado. Reabra o app com permissão Bluetooth para recuperar.";notice(cleanupError);}
        phase(cleanupError==null?Phase.CLOSED:Phase.ERROR,cleanupError==null?"Sessão encerrada; controles bloqueados.":cleanupError);
    }
}
