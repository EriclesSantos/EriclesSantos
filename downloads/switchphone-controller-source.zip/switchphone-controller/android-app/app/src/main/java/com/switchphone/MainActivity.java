package com.switchphone;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.switchphone.bluetooth.*;
import com.switchphone.controller.ControllerState;
import com.switchphone.layouts.*;
import com.switchphone.settings.Preferences;
import java.util.ArrayList;
import java.util.ArrayDeque;

/** Native offline UI; indicators follow confirmed transport/protocol callbacks. */
public final class MainActivity extends Activity {
    private static final int PERMISSIONS=1,ENABLE_BT=2,VISIBLE_BT=3;
    private final ControllerState state=new ControllerState();
    private final ArrayDeque<String> diagnostics=new ArrayDeque<>();
    private Preferences prefs;
    private HidSession session;
    private TextView status,detail;
    private ConnectionIndicator indicator;
    private Button pairButton,reconnectButton,stopButton;
    private ControllerView controller;
    private BluetoothAdapter adapter;
    private HidSession.Phase phase=HidSession.Phase.IDLE;
    private String message="Desconectado • escolha PC ou Switch e toque Parear";
    private String notice="Botões cinzas ficam bloqueados até a conexão ser confirmada.";
    private String screen="home";
    private boolean pairing,visibilityRequested,externalRequest;
    private final android.os.Handler ui=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable pairTimeout;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);prefs=new Preferences(this);
        BluetoothManager manager=getSystemService(BluetoothManager.class);
        adapter=manager==null?null:manager.getAdapter();
        getWindow().setStatusBarColor(Color.rgb(12,19,28));getWindow().setNavigationBarColor(Color.rgb(12,19,28));
        if(adapter!=null&&permitted()){
            try{new IdentityLease(this).recover(adapter);}catch(SecurityException|IllegalStateException e){notice="Não foi possível restaurar o nome Bluetooth. Tente Parear com Bluetooth ligado.";phase=HidSession.Phase.ERROR;message="Falha na recuperação do nome Bluetooth.";}
        }
        home();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout base(String title,String selected){
        release();controller=null;screen=selected;reconnectButton=stopButton=null;
        getWindow().getDecorView().setSystemUiVisibility(selected.equals("control")
            ?View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY:View.SYSTEM_UI_FLAG_VISIBLE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(6),dp(14),dp(6));root.setBackgroundColor(Color.rgb(12,19,28));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(dp(14)+insets.getSystemWindowInsetLeft(),dp(6)+insets.getSystemWindowInsetTop(),dp(14)+insets.getSystemWindowInsetRight(),dp(6)+insets.getSystemWindowInsetBottom());return insets;
        });
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header);
        TextView name=text(title,18);name.setTextColor(Color.rgb(77,220,197));header.addView(name,new LinearLayout.LayoutParams(0,dp(40),1));
        indicator=new ConnectionIndicator(this);header.addView(indicator,new LinearLayout.LayoutParams(dp(36),dp(18)));
        pairButton=button(header,"Parear",this::pair);
        if(!selected.equals("home"))button(header,"Início",this::home);
        status=text(message,12);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);root.addView(status);
        detail=text(notice,11);detail.setMaxLines(2);detail.setTextColor(Color.rgb(166,181,197));root.addView(detail);
        setContentView(root);refresh();return root;
    }
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.rgb(220,231,240));t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private void info(LinearLayout root,String value){TextView t=text(value,14);t.setPadding(0,dp(6),0,dp(6));root.addView(t);}
    private Button button(LinearLayout parent,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);parent.addView(b);b.setOnClickListener(v->action.run());return b;
    }
    private void home(){
        LinearLayout root=base("SWITCHPHONE","home");
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);
        info(content,"Bluetooth clássico • offline • sem root. Escolha o destino:");
        LinearLayout modes=new LinearLayout(this);content.addView(modes);
        button(modes,prefs.nintendo()?"PC":"✓ PC",()->mode(false));
        button(modes,prefs.nintendo()?"✓ Switch experimental":"Switch experimental",()->mode(true));
        info(content,prefs.nintendo()?"Pro Controller experimental para Switch com MissionControl. Parear altera temporariamente o nome Bluetooth para Pro Controller; o nome anterior é restaurado ao encerrar. Compatibilidade ainda não validada em hardware.":"Gamepad genérico para computador. Não é XInput; jogos podem exigir mapeamento. Nenhum sistema foi validado fisicamente.");
        LinearLayout row=new LinearLayout(this);content.addView(row);
        reconnectButton=button(row,"Reconectar",this::reconnect);stopButton=button(row,"Encerrar",this::stop);button(row,"Diagnóstico",this::diagnostics);
        LinearLayout nav=new LinearLayout(this);content.addView(nav);
        button(nav,"Abrir controle",this::control);button(nav,"Layouts",this::layouts);button(nav,"Configurações",this::settings);
        info(content,"Layout: "+ControllerView.NAMES[prefs.layout()]+". Toque Parear no topo, aceite os pedidos do Android e inicie o pareamento pelo "+(prefs.nintendo()?"Switch em Controles → Mudar ordem/modo de segurar.":"computador. No Windows, confira entradas em Win+R → joy.cpl."));
        if(adapter==null)info(content,"Este dispositivo não oferece adaptador Bluetooth.");refresh();
    }
    private void mode(boolean nintendo){stop();prefs.put("protocol",nintendo?1:0);home();}
    private void control(){
        LinearLayout root=base(prefs.nintendo()?"SWITCH • EXPERIMENTAL":"CONTROLE • PC","control");
        LinearLayout actions=new LinearLayout(this);root.addView(actions);
        reconnectButton=button(actions,"Reconectar",this::reconnect);stopButton=button(actions,"Encerrar",this::stop);
        button(actions,"Layout",this::layouts);button(actions,"Ajustes",this::settings);button(actions,"Diagnóstico",this::diagnostics);
        controller=new ControllerView(this,prefs.layout(),state,prefs,this::send,false);
        root.addView(controller,new LinearLayout.LayoutParams(-1,0,1));refresh();
    }
    private void layouts(){
        LinearLayout root=base("LAYOUTS","layouts");LinearLayout row=new LinearLayout(this);root.addView(row);
        final int[] selected={prefs.layout()};FrameLayout preview=new FrameLayout(this);
        for(int i=0;i<3;i++){
            final int choice=i;button(row,ControllerView.NAMES[i],()->{selected[0]=choice;preview.removeAllViews();preview.addView(new ControllerView(this,choice,new ControllerState(),prefs,()->{},true));});
        }
        button(row,"Selecionar",()->{prefs.put("layout",selected[0]);control();});
        preview.addView(new ControllerView(this,selected[0],new ControllerState(),prefs,()->{},true));root.addView(preview,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void settings(){
        LinearLayout root=base("CONFIGURAÇÕES","settings");ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);
        slider(content,"Zona morta","deadZone",prefs.deadZone(),0,30);slider(content,"Sensibilidade","sensitivity",prefs.sensitivity(),50,150);slider(content,"Vibração local","vibration",prefs.vibration(),0,100);
        LinearLayout row=new LinearLayout(this);content.addView(row);button(row,"Layout padrão",this::layouts);button(row,"Diagnóstico",this::diagnostics);
        button(row,"Compatibilidade",()->new AlertDialog.Builder(this).setTitle("Compatibilidade experimental")
            .setMessage("Android 9+ com perfil HID Device habilitado pelo fabricante. PC: HID genérico, não XInput. Switch: emulação parcial Pro Controller, sem root, para testar com MissionControl. MAC/VID/PID reais são controlados pelo Android; isso pode impedir o reconhecimento. Não implementa NFC, giroscópio, rumble do jogo ou pareamento manual com chaves privadas. LEDs verdes confirmam enlace e negociação, não o funcionamento num jogo. Nenhum telefone/console validado fisicamente.").setPositiveButton("Entendi",null).show());
    }
    private void slider(LinearLayout parent,String label,String key,int value,int minimum,int maximum){
        TextView caption=text(String.format(java.util.Locale.getDefault(),"%s: %d%%",label,value),15);parent.addView(caption);
        SeekBar seek=new SeekBar(this);seek.setMax(maximum-minimum);seek.setProgress(value-minimum);seek.setContentDescription(label);parent.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar bar,int progress,boolean user){int v=progress+minimum;caption.setText(String.format(java.util.Locale.getDefault(),"%s: %d%%",label,v));if(user)prefs.put(key,v);}
            @Override public void onStartTrackingTouch(SeekBar bar){} @Override public void onStopTrackingTouch(SeekBar bar){}
        });
    }
    private boolean busy(){return phase==HidSession.Phase.REQUESTING||phase==HidSession.Phase.REGISTERING||phase==HidSession.Phase.CONNECTING||phase==HidSession.Phase.NEGOTIATING||(pairing&&phase==HidSession.Phase.READY);}
    private void refresh(){
        boolean active=phase==HidSession.Phase.ACTIVE&&session!=null&&session.inputReady();
        if(indicator!=null)indicator.status(busy(),active,phase==HidSession.Phase.ERROR);
        if(status!=null){status.setText(message);status.setTextColor(phase==HidSession.Phase.ERROR?Color.rgb(255,128,123):active?Color.rgb(74,222,128):Color.rgb(220,231,240));}
        if(detail!=null)detail.setText(notice);
        if(pairButton!=null){pairButton.setText(active?"Conectado":busy()?"Pareando…":"Parear");pairButton.setEnabled(!busy()&&!active&&adapter!=null);}
        if(reconnectButton!=null)reconnectButton.setEnabled(session!=null&&session.registered()&&!session.connected()&&!busy());
        if(stopButton!=null)stopButton.setEnabled(session!=null||pairing);
        if(controller!=null)controller.setInputAvailable(active);
    }
    private void log(String value){if(diagnostics.size()>=60)diagnostics.removeFirst();diagnostics.addLast(value);}
    private void update(HidSession.Phase value,String text){phase=value;message=text;log(text);refresh();}
    private void notice(String value){notice=value;log(value);refresh();}
    private void diagnostics(){
        TextView body=text(diagnostics.isEmpty()?"Nenhum evento nesta sessão.":String.join("\n\n",diagnostics),13);body.setPadding(dp(16),dp(10),dp(16),dp(10));
        ScrollView scroll=new ScrollView(this);scroll.addView(body);new AlertDialog.Builder(this).setTitle("Diagnóstico da sessão").setView(scroll).setPositiveButton("Fechar",null).show();
    }
    private boolean permitted(){return Build.VERSION.SDK_INT<31||(checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)==PackageManager.PERMISSION_GRANTED);}
    private void pair(){stop();notice("Siga as confirmações do Android. O app aguardará o host Bluetooth.");pairing=true;visibilityRequested=false;prepare();}
    private void prepare(){
        if(!permitted()){externalRequest=true;update(HidSession.Phase.REQUESTING,"Aguardando permissão de dispositivos próximos…");requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_ADVERTISE},PERMISSIONS);return;}
        try{
            if(adapter==null){pairing=false;update(HidSession.Phase.ERROR,"Bluetooth indisponível.");return;}
            if(!adapter.isEnabled()){externalRequest=true;update(HidSession.Phase.REQUESTING,"Aguardando ativação do Bluetooth…");startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),ENABLE_BT);return;}
            if(session!=null&&(session.phase()==HidSession.Phase.ERROR||session.phase()==HidSession.Phase.CLOSED)){session.close();session=null;}
            if(session==null)session=new HidSession(this,state,prefs.nintendo(),new HidSession.Listener(){
                @Override public void status(HidSession.Phase next,String text){
                    update(next,text);
                    if(next==HidSession.Phase.READY&&pairing&&!visibilityRequested)discoverable();
                    if(next==HidSession.Phase.ACTIVE||next==HidSession.Phase.ERROR)pairing=false;
                    refresh();
                }
                @Override public void resetInput(){if(controller!=null)controller.release();}
                @Override public void notice(String text){MainActivity.this.notice(text);}
            });
            session.start();
        }catch(SecurityException|android.content.ActivityNotFoundException e){externalRequest=false;pairing=false;update(HidSession.Phase.ERROR,"Não foi possível abrir Bluetooth. Confira as permissões nas configurações do Android.");}
    }
    private void discoverable(){
        try{
            visibilityRequested=true;externalRequest=true;notice("Confirme a visibilidade. Depois selecione o telefone no host dentro de 120 segundos.");
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,120),VISIBLE_BT);
        }catch(SecurityException|android.content.ActivityNotFoundException e){externalRequest=false;pairing=false;update(HidSession.Phase.ERROR,"Visibilidade Bluetooth indisponível neste Android.");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);externalRequest=false;
        if(request==ENABLE_BT){if(result==RESULT_OK){pairing=true;prepare();}else{pairing=false;update(HidSession.Phase.ERROR,"Bluetooth não foi ativado. Toque Parear para tentar novamente.");}}
        else if(request==VISIBLE_BT){
            if(result>0){pairing=true;visibilityRequested=true;prepare();notice("Visível por "+result+" segundos. Inicie o pareamento pelo host.");waitForHost();}
            else{pairing=false;stop();update(HidSession.Phase.ERROR,"Visibilidade cancelada. Toque Parear para tentar novamente.");}
        }
    }
    private void waitForHost(){
        final HidSession expected=session;
        if(pairTimeout!=null)ui.removeCallbacks(pairTimeout);
        pairTimeout=()->{
            if(session==expected&&session!=null&&!session.connected()&&pairing){pairing=false;update(HidSession.Phase.ERROR,"Nenhum host conectou no prazo de visibilidade. Toque Parear para tentar novamente.");}
        };ui.postDelayed(pairTimeout,120000);refresh();
    }
    private void reconnect(){
        if(!permitted()||session==null){pair();return;}
        try{
            ArrayList<BluetoothDevice> devices=new ArrayList<>(adapter.getBondedDevices());
            if(devices.isEmpty()){notice("Nenhum host pareado. Use Parear primeiro.");return;}
            String[] names=new String[devices.size()];for(int i=0;i<names.length;i++)names[i]=devices.get(i).getName()==null?"Dispositivo pareado "+(i+1):devices.get(i).getName();
            new AlertDialog.Builder(this).setTitle("Escolha o host HID").setItems(names,(dialog,which)->{if(session!=null)session.reconnect(devices.get(which));}).show();
        }catch(SecurityException e){update(HidSession.Phase.ERROR,"Permissão Bluetooth revogada.");}
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);externalRequest=false;if(code==PERMISSIONS){if(permitted()){pairing=true;prepare();}else{pairing=false;update(HidSession.Phase.ERROR,"Permissão negada. Dispositivos próximos é necessário para Bluetooth no Android 12+.");}}
    }
    private void send(){if(session!=null)session.send();}
    private void release(){if(controller!=null)controller.release();state.clear();if(session!=null)session.release();}
    private void stop(){externalRequest=false;pairing=false;if(pairTimeout!=null)ui.removeCallbacks(pairTimeout);release();if(session!=null){session.close();boolean cleanupError=session.phase()==HidSession.Phase.ERROR;session=null;if(cleanupError){refresh();return;}}update(HidSession.Phase.CLOSED,"Sessão encerrada; controles bloqueados.");}
    @Override protected void onPause(){release();super.onPause();}
    @Override protected void onStop(){
        // A system Bluetooth dialog may stop us. Its result resumes pairing automatically.
        if(externalRequest){release();if(session!=null){session.close();session=null;}update(HidSession.Phase.REQUESTING,"Aguardando confirmação do Android…");}else stop();super.onStop();
    }
    @Override protected void onDestroy(){ui.removeCallbacksAndMessages(null);if(session!=null)session.close();super.onDestroy();}
    @Override public void onBackPressed(){if(!screen.equals("home"))home();else super.onBackPressed();}
}
