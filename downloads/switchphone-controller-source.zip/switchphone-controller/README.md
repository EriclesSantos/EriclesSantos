# SwitchPhone Controller 0.2.0 — experimental

Android nativo em Java, API 28+, offline, sem root, servidor, anúncios ou telemetria. Não há permissão Internet no APK.

**Dois modos Bluetooth clássico:** gamepad HID genérico para PC (não XInput) e emulação parcial de Pro Controller para experimentar com Nintendo Switch/Atmosphère/MissionControl. Nenhum telefone, computador ou console foi validado fisicamente. Compatibilidade não é universal.

## Interface e controles
- Layouts Nintendo Switch, Xbox e PlayStation desenhados em Canvas, com prévia e seleção persistente. O layout visual é independente do modo Bluetooth.
- Multitoque, dois analógicos, direcional com diagonais, ombros, gatilhos, Home/Capture, Menu/View e L3/R3.
- Zona morta, sensibilidade e vibração local configuráveis. Não há rumble comandado pelo jogo.
- Botão **Parear** no topo conduz permissões, ativação do Bluetooth, registro HID e visibilidade.
- Três pontos vermelhos pulsantes enquanto aguarda; verdes após confirmação de enlace (PC) e negociação de modo (Nintendo); vermelhos fixos em erro, cinzas quando encerrado.
- Controles cinza e rebaixados ficam bloqueados até confirmação. Perda de conexão, cancelamento de toque e saída liberam estados.
- Mensagens de progresso/erro e histórico local de diagnóstico, sem endereços Bluetooth ou chaves.

## Nintendo experimental
Implementa descritor próprio, relatórios `0x3F`, `0x21`, `0x30`, identificação virtual, negociação de modo, botões/eixos nativos, leitura de calibração virtual SPI, LEDs de jogador e contadores de gatilhos. Transmite `0x30` aproximadamente 59 vezes/s somente conectado e negociado.

Não implementa NFC, giroscópio, rumble, atualização de firmware ou acesso a chaves de pareamento do sistema. Pedidos não suportados recebem NACK/erro explícito e aparecem no diagnóstico. Isso pode impedir a negociação em determinados hosts. MAC/VID/PID reais continuam sob controle do Android. O nome Bluetooth é temporariamente alterado para `Pro Controller`, com recuperação persistida do nome anterior.

**Pontos verdes não comprovam que o jogo reconheceu os botões.** O app não recebe confirmação do consumo de cada entrada. As calibrações e identidade são virtuais para este aplicativo, não dumps de um controle original.

## Compilar e testar
Abra `android-app` no Android Studio com JDK 17 ou 21, SDK Platform 35 e Build Tools 35.0.0. Gradle Wrapper 8.9 e AGP 8.7.3 estão fixados.

```sh
./tests/run.sh
cd android-app
./gradlew assembleDebug lintDebug
```

APK debug: `android-app/app/build/outputs/apk/debug/app-debug.apk`. Não é release de produção. Build requer Internet; jogar não depende dela.

Leia [instalação e testes físicos](docs/installation.md), [protocolo](docs/nintendo-protocol.md), [pesquisa](docs/bluetooth-research.md), [arquitetura](docs/architecture.md), [compatibilidade](docs/compatibility.md), [validação](docs/validation.md) e [roadmap](docs/roadmap.md).

Código original MIT; não foi incorporado código dos projetos pesquisados. O Gradle Wrapper tem seus [avisos de terceiros](docs/third-party-notices.md). O workflow GitHub Actions compila e disponibiliza o APK como artefato; publicação em Releases e assinatura de produção ficam para depois dos testes físicos.
