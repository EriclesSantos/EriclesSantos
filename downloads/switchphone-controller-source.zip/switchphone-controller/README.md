# SwitchPhone Controller 0.2.2 — experimental

Android nativo em Java, API 28+, offline, sem root, servidor, anúncios ou telemetria. Não há permissão Internet no APK.

**Dois modos Bluetooth clássico:** gamepad HID genérico para PC (não XInput) e emulação parcial de Pro Controller para experimentar com Nintendo Switch/Atmosphère/MissionControl. Nenhum telefone, computador ou console foi validado fisicamente. Compatibilidade não é universal.

## Interface e controles
- Layouts Nintendo Switch, Xbox e PlayStation desenhados em Canvas, com prévia e seleção persistente. O layout visual é independente do modo Bluetooth.
- Multitoque, dois analógicos, direcional com diagonais, ombros, gatilhos, Home/Capture, Menu/View e L3/R3.
- Zona morta, sensibilidade e vibração local configuráveis. Não há rumble comandado pelo jogo.
- Botão **Parear** no topo conduz permissões, ativação, confirmação do nome e visibilidade; só depois do retorno ao app registra HID. Não repete solicitações automaticamente na mesma tentativa.
- Três pontos vermelhos pulsantes enquanto aguarda; verdes após confirmação de enlace (PC) e negociação de modo (Nintendo); vermelhos fixos em erro, cinzas quando encerrado.
- Parear abre a tela interativa. Controles ficam disponíveis após o enlace HID, inclusive antes da negociação Nintendo, para permitir L+R. Sem enlace ficam cinza e rebaixados. Perda de conexão, cancelamento e saída liberam estados.
- **Confirmar L+R** envia um pulso de 300 ms sem sobrescrever dedos mantidos na tela. **Testar toque** usa um estado separado e nunca envia comandos por Bluetooth.
- Contagem regressiva de até 120 s, mensagens por etapa e diagnóstico copiável com modelo/Android/permissões e eventos de vínculo; sem MAC, nome pessoal do telefone ou chaves.
- Uma sessão em primeiro plano com notificação mantém o HID durante a confirmação Bluetooth do sistema. Não há busca ativa; o app aguarda o Switch/computador. A sessão termina ao cancelar, expirar, falhar ou sair do controle ativo.
- Mensagens de progresso/erro e histórico local de diagnóstico, sem endereços Bluetooth ou chaves.

## Nintendo experimental
Implementa descritor próprio, relatórios `0x3F`, `0x21`, `0x30`, identificação virtual, negociação de modo, botões/eixos nativos, leitura de calibração virtual SPI, LEDs de jogador e contadores de gatilhos. Transmite `0x30` aproximadamente 59 vezes/s somente conectado e negociado.

Não implementa NFC, giroscópio, rumble, atualização de firmware ou acesso a chaves de pareamento do sistema. Pedidos não suportados recebem NACK/erro explícito e aparecem no diagnóstico. Isso pode impedir a negociação em determinados hosts. MAC/VID/PID reais continuam sob controle do Android. O nome Bluetooth é temporariamente alterado para `Pro Controller`, com recuperação persistida do nome anterior.

**Pontos verdes não comprovam que o jogo reconheceu os botões.** O app não recebe confirmação do consumo de cada entrada. As calibrações e identidade são virtuais para este aplicativo, não dumps de um controle original.

## Compilar e testar
Abra `android-app` no Android Studio com JDK 17 ou 21, SDK Platform 35 e Build Tools 35.0.0. Gradle Wrapper 8.9 e AGP 8.7.3 estão fixados.

```sh
./tests/run.sh
cd android-app
./gradlew assembleDebug lintDebug
```

APK debug: `android-app/app/build/outputs/apk/debug/app-debug.apk`. Não é release de produção. Build requer Internet; jogar não depende dela.

Leia [instalação e testes físicos](docs/installation.md), [protocolo](docs/nintendo-protocol.md), [pesquisa](docs/bluetooth-research.md), [arquitetura](docs/architecture.md), [compatibilidade](docs/compatibility.md), [validação](docs/validation.md) e [roadmap](docs/roadmap.md).

Código original MIT; não foi incorporado código dos projetos pesquisados. O Gradle Wrapper tem seus [avisos de terceiros](docs/third-party-notices.md). O workflow GitHub Actions compila e disponibiliza o APK como artefato; publicação em Releases e assinatura de produção ficam para depois dos testes físicos.

## Distribuição e Play Protect

O APK 0.2.2 de download usa a mesma chave própria da 0.2.1 e build release não depurável e assinatura própria do projeto; a versão 0.2.0 usava Android Debug. A 0.2.1 alterou apenas a distribuição. A 0.2.2 adiciona o serviço foreground para manter o perfil durante pareamento, preservando package ID e assinatura; não altera o app para contornar o Play Protect. App novo distribuído fora da Play Store ainda pode gerar aviso de desenvolvedor desconhecido. Assinatura própria não equivale à revisão/aprovação pelo Google e não garante retirada do alerta.

Para reproduzir o release: execute `./gradlew assembleRelease lintRelease` em android-app e use scripts/sign-release.sh com ANDROID_HOME, SIGNING_KEYSTORE e SIGNING_PASSWORD_FILE apontando para seus arquivos privados. Nunca publique a chave ou sua senha. Preserve uma cópia segura da chave estável para permitir futuras atualizações. Uma chave diferente exige desinstalar o build antigo antes da instalação.

## Teste no Switch Lite

Use **Controles → Mudar ordem/modo de segurar**. No app selecione o destino **Switch experimental**, toque Parear e aceite **Associer** no Android sem marcar acesso aos contatos. Quando o enlace HID existir, pressione **Confirmar L+R**. A tela Layouts é apenas uma prévia; Parear/Selecionar abrem a tela de controle real. Se falhar, use Diagnóstico → Copiar. A captura enviada da 0.2.1 confirma uma tentativa de vínculo Android com Nintendo Switch; não confirma reconhecimento como controle ou funcionamento em jogo.
