@echo off
setlocal
title SwitchPhone - codigos Bluetooth
echo SwitchPhone: coleta numerica de erro Bluetooth pelo USB.
echo Nao precisa executar como administrador.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-Bluetooth.ps1"
echo.
pause
endlocal
